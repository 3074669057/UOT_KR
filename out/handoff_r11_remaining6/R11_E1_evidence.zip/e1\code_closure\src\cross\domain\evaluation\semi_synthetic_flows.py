"""Semi-synthetic weak flow labels to stress split / merge / unmatched / noise."""
from __future__ import annotations

import json
import random
from copy import deepcopy
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from cross.config.output_layout import output_file


def _pick_seeds_head(fl: pd.DataFrame, *, rng: random.Random, max_seeds: int = 8) -> list[dict[str, Any]]:
    if fl.empty:
        return []
    oo = fl[fl.get("pattern_type", "").astype(str).str.lower() == "one_to_one"].copy()
    if oo.empty:
        oo = fl.copy()
    oo["_lc"] = pd.to_numeric(oo.get("label_confidence"), errors="coerce").fillna(0.0)
    oo = oo.sort_values("_lc", ascending=False)
    rows = oo.head(max_seeds).to_dict(orient="records")
    rng.shuffle(rows)
    return rows


def _assign_quantile_labels(series: pd.Series, n_bins: int, *, prefix: str) -> pd.Series:
    s = pd.to_numeric(series, errors="coerce").fillna(0.0)
    if s.nunique() < n_bins:
        ranks = s.rank(method="first")
        nb = max(1, min(n_bins, int(s.nunique())))
        return pd.cut(ranks, bins=nb, labels=[f"{prefix}{i}" for i in range(nb)], include_lowest=True)
    try:
        return pd.qcut(s, q=n_bins, labels=[f"{prefix}{i}" for i in range(n_bins)], duplicates="drop")
    except ValueError:
        ranks = s.rank(method="first")
        return pd.cut(ranks, bins=n_bins, labels=[f"{prefix}{i}" for i in range(n_bins)], include_lowest=True)


def _pick_seeds_stratified(
    fl: pd.DataFrame,
    *,
    rng: random.Random,
    max_seeds: int = 48,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Stratified sample: 4 amount quartiles × 3 delay tertiles → 12 cells × 4 seeds = 48."""
    diag: dict[str, Any] = {
        "requested_seeds": int(max_seeds),
        "cells_target_per_cell": 4,
        "cells": [],
        "backfill": [],
    }
    if fl.empty:
        return [], diag

    pool = fl[fl.get("pattern_type", "").astype(str).str.lower() == "one_to_one"].copy()
    if pool.empty:
        pool = fl.copy()
    pool = pool.copy()
    pool["_amt"] = pd.to_numeric(pool.get("src_amount_usd"), errors="coerce").fillna(0.0)
    pool["_delay"] = pd.to_numeric(pool.get("median_delay_sec"), errors="coerce").fillna(0.0)
    pool["_amt_q"] = _assign_quantile_labels(pool["_amt"], 4, prefix="Q")
    pool["_delay_q"] = _assign_quantile_labels(pool["_delay"], 3, prefix="D")
    pool["_cell"] = pool["_amt_q"].astype(str) + "|" + pool["_delay_q"].astype(str)

    n_cells = 12
    per_cell = max(1, int(max_seeds // n_cells))
    diag["cells_target_per_cell"] = per_cell

    chosen_idx: set[int] = set()
    chosen_rows: list[dict[str, Any]] = []

    for cell, grp in pool.groupby("_cell", sort=False):
        idxs = list(grp.index)
        rng.shuffle(idxs)
        take = idxs[:per_cell]
        deficit = per_cell - len(take)
        for i in take:
            chosen_idx.add(int(i))
            chosen_rows.append(pool.loc[i].to_dict())
        diag["cells"].append(
            {
                "cell": str(cell),
                "available": int(len(idxs)),
                "sampled": int(len(take)),
                "deficit": int(max(0, deficit)),
            }
        )

    if len(chosen_rows) < max_seeds:
        remaining = [i for i in pool.index if int(i) not in chosen_idx]
        rng.shuffle(remaining)
        need = max_seeds - len(chosen_rows)
        for i in remaining[:need]:
            chosen_idx.add(int(i))
            chosen_rows.append(pool.loc[i].to_dict())
            diag["backfill"].append({"index": int(i), "cell": str(pool.loc[i, "_cell"])})

    chosen_rows = chosen_rows[:max_seeds]
    rng.shuffle(chosen_rows)
    diag["sampled_total"] = int(len(chosen_rows))
    diag["unique_cells_hit"] = int(len({str(r.get("_cell", "")) for r in chosen_rows}))
    return chosen_rows, diag


def pick_semi_synthetic_seeds(
    fl: pd.DataFrame,
    *,
    rng: random.Random,
    max_seeds: int = 8,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Pick template rows; use stratified grid when ``max_seeds > 8``."""
    if max_seeds > 8:
        return _pick_seeds_stratified(fl, rng=rng, max_seeds=max_seeds)
    rows = _pick_seeds_head(fl, rng=rng, max_seeds=max_seeds)
    return rows, {"mode": "head_confidence", "sampled_total": len(rows)}


def build_semi_synthetic_from_flow_labels(
    flow_labels_path: Path,
    flow_label_stats_path: Path,
    out_dir: Path,
    *,
    seed: int = 42,
    max_seeds: int = 8,
    force: bool = False,
) -> tuple[Path, Path]:
    """Derive synthetic ``flow_labels``-shaped rows from real labels when data is mostly 1:1.

    When ``predominantly_one_to_one`` is false in stats, generation is skipped unless ``force=True``.
    Writes ``synthetic_seed_stratification.json`` when ``max_seeds > 8``.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    fl = pd.read_csv(flow_labels_path, dtype=str, keep_default_na=False)
    stats: dict[str, Any] = {}
    if flow_label_stats_path.is_file():
        stats = json.loads(flow_label_stats_path.read_text(encoding="utf-8"))

    predominantly_1_1 = bool(stats.get("predominantly_one_to_one"))
    if not predominantly_1_1 and not force:
        out_csv = output_file(out_dir, "synthetic_flow_labels.csv")
        pd.DataFrame().to_csv(out_csv, index=False)
        out_json = output_file(out_dir, "synthetic_uot_eval_metrics.json")
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "skipped": True,
                    "reason": "not_predominantly_one_to_one",
                    "predominantly_one_to_one": predominantly_1_1,
                    "seed": int(seed),
                    "max_seeds": int(max_seeds),
                },
                f,
                indent=2,
                ensure_ascii=False,
            )
        return out_csv, out_json

    rng = random.Random(int(seed))
    seeds, strat_diag = pick_semi_synthetic_seeds(fl, rng=rng, max_seeds=int(max_seeds))
    strat_diag["random_seed"] = int(seed)
    strat_diag["max_seeds"] = int(max_seeds)
    strat_path = output_file(out_dir, "synthetic_seed_stratification.json")
    with open(strat_path, "w", encoding="utf-8") as f:
        json.dump(strat_diag, f, indent=2, ensure_ascii=False)

    rows: list[dict[str, Any]] = []
    truth_pairs: list[list[str]] = []
    truth_unmatched_src: list[str] = []
    noise_pairs: list[list[str]] = []
    clone_records: list[dict[str, Any]] = []

    def _base(r: dict[str, Any]) -> dict[str, Any]:
        b = deepcopy(r)
        for k in list(b.keys()):
            if str(k).startswith("_"):
                del b[k]
        return b

    for r in seeds:
        base = _base(r)
        sf = str(base.get("src_flow_id") or "synth_src")
        df = str(base.get("dst_flow_id") or "synth_dst")
        amt = float(pd.to_numeric(base.get("src_amount_usd"), errors="coerce") or 0.0)
        half = max(amt * 0.5, 1e-9)

        s_split = f"{sf}__synth_split_src"
        d1, d2 = f"{df}__synth_split_a", f"{df}__synth_split_b"
        r1 = {
            **base,
            "src_flow_id": s_split,
            "dst_flow_id": d1,
            "pattern_type": "one_to_many",
            "label_source": "semi_synthetic_split",
            "support_tx_pair_count": "1",
            "src_amount_usd": str(amt),
            "dst_amount_usd": str(half),
            "matched_src_amount_usd": str(half),
            "matched_dst_amount_usd": str(half),
            "label_confidence": str(min(0.95, float(pd.to_numeric(base.get("label_confidence"), errors="coerce") or 0.6))),
        }
        r2 = {**r1, "dst_flow_id": d2, "matched_dst_amount_usd": str(half)}
        rows.extend([r1, r2])
        truth_pairs.append([s_split, d1])
        truth_pairs.append([s_split, d2])
        clone_records.extend(
            [
                {"synthetic_flow_id": s_split, "template_flow_id": sf, "chain": "ETH", "amount_scale": 1.0, "scenario": "split"},
                {"synthetic_flow_id": d1, "template_flow_id": df, "chain": "BNB", "amount_scale": 0.5, "scenario": "split"},
                {"synthetic_flow_id": d2, "template_flow_id": df, "chain": "BNB", "amount_scale": 0.5, "scenario": "split"},
            ]
        )

        s1, s2 = f"{sf}__synth_merge_src1", f"{sf}__synth_merge_src2"
        dm = f"{df}__synth_merge_dst"
        m1 = {
            **base,
            "src_flow_id": s1,
            "dst_flow_id": dm,
            "pattern_type": "many_to_one",
            "label_source": "semi_synthetic_merge",
            "src_amount_usd": str(half),
            "dst_amount_usd": str(amt),
            "matched_src_amount_usd": str(half),
            "matched_dst_amount_usd": str(half),
        }
        m2 = {**m1, "src_flow_id": s2}
        rows.extend([m1, m2])
        truth_pairs.append([s1, dm])
        truth_pairs.append([s2, dm])
        clone_records.extend(
            [
                {"synthetic_flow_id": s1, "template_flow_id": sf, "chain": "ETH", "amount_scale": 0.5, "scenario": "merge"},
                {"synthetic_flow_id": s2, "template_flow_id": sf, "chain": "ETH", "amount_scale": 0.5, "scenario": "merge"},
                {"synthetic_flow_id": dm, "template_flow_id": df, "chain": "BNB", "amount_scale": 1.0, "scenario": "merge"},
            ]
        )

        su = f"{sf}__synth_unmatched_src"
        hidden = f"{df}__synth_hidden_dst"
        u1 = {
            **base,
            "src_flow_id": su,
            "dst_flow_id": hidden,
            "pattern_type": "one_to_one",
            "label_source": "semi_synthetic_unmatched",
            "dst_amount_usd": "0",
            "matched_dst_amount_usd": "0",
            "flow_mass_ratio_dst": "0",
            "label_confidence": "0.2",
        }
        rows.append(u1)
        truth_unmatched_src.append(su)
        clone_records.extend(
            [
                {"synthetic_flow_id": su, "template_flow_id": sf, "chain": "ETH", "amount_scale": 1.0, "scenario": "unmatched"},
                {"synthetic_flow_id": hidden, "template_flow_id": df, "chain": "BNB", "amount_scale": 0.0, "scenario": "unmatched"},
            ]
        )

        for i in range(2):
            decoy_s = f"{sf}__synth_noise_src_{i}"
            decoy_d = f"{df}__synth_noise_dst_{i}"
            n1 = {
                **base,
                "src_flow_id": decoy_s,
                "dst_flow_id": decoy_d,
                "pattern_type": "one_to_one",
                "label_source": "semi_synthetic_delay_noise",
                "label_confidence": str(round(0.22 + 0.04 * rng.random(), 4)),
                "median_delay_sec": str(int(pd.to_numeric(base.get("median_delay_sec"), errors="coerce") or 0) + 60 + i * 60),
            }
            rows.append(n1)
            noise_pairs.append([decoy_s, decoy_d])
            clone_records.extend(
                [
                    # Real timestamp perturbation for decoy flows: the destination leg is
                    # shifted (+60s / +120s) so decoy segments do not reuse the template's
                    # original timestamps (root cause C of the retracted run).
                    {"synthetic_flow_id": decoy_s, "template_flow_id": sf, "chain": "ETH",
                     "amount_scale": 1.0, "time_offset_sec": 0.0, "scenario": "delay_noise"},
                    {"synthetic_flow_id": decoy_d, "template_flow_id": df, "chain": "BNB",
                     "amount_scale": 1.0, "time_offset_sec": 60.0 + 60.0 * i, "scenario": "delay_noise"},
                ]
            )

    out_csv = output_file(out_dir, "synthetic_flow_labels.csv")
    pd.DataFrame(rows).to_csv(out_csv, index=False)

    metrics: dict[str, Any] = {
        "predominantly_one_to_one": predominantly_1_1,
        "forced": bool(force),
        "seed": int(seed),
        "max_seeds": int(max_seeds),
        "seed_templates_used": int(len(seeds)),
        "synthetic_row_count": int(len(rows)),
        "stratification_path": str(strat_path.resolve()),
        "scenario_counts": {
            "split_edges": int(sum(1 for r in rows if "semi_synthetic_split" in str(r.get("label_source", "")))),
            "merge_edges": int(sum(1 for r in rows if "semi_synthetic_merge" in str(r.get("label_source", "")))),
            "unmatched_labels": int(sum(1 for r in rows if "semi_synthetic_unmatched" in str(r.get("label_source", "")))),
            "noise_edges": int(sum(1 for r in rows if "semi_synthetic_delay_noise" in str(r.get("label_source", "")))),
        },
        "segment_clone_records": clone_records,
        "eval_hints": {
            "truth_flow_pairs": truth_pairs,
            "truth_unmatched_src_flows": truth_unmatched_src,
            "noise_decoy_pairs": noise_pairs,
        },
    }
    out_json = output_file(out_dir, "synthetic_uot_eval_metrics.json")
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2, ensure_ascii=False)
    return out_csv, out_json
