# HOLDOUT_DECISION_RULES.md

Date: 2026-09-02 (Asia/Shanghai). Frozen BEFORE holdout execution. The decision tree
below may not be changed after holdout observation, regardless of outcome.

## Clarification amendment (2026-09-02, pre-holdout; MINIMAL, operational only)

The scientific thresholds above are unchanged. This amendment only fixes the
aggregation level of two clauses so the machinery can evaluate them deterministically.
No threshold was chosen using any holdout data (none exists).

1. **Mechanism gate B — exact operationalization.** B passes iff ALL FIVE indicators
   move in the repair direction at the MACRO (three-bridge pooled) level:
   row harmful flip rate DECREASES, column harmful flip rate DECREASES, split-child
   harmful flip rate DECREASES, merge-dst harmful flip rate DECREASES, and GT
   mutual-top5 retention INCREASES, each comparing CONDITIONAL_UOT_D4 against
   RAW_UOT_PLAN_D4 on the same paired template units. Per-bridge directions are
   reported descriptively and do not enter the gate.

2. **Convergence-failure rule (clause E) — exact operationalization.** A holdout cell
   is a convergence failure iff its frozen UOT solve has final_err >= 1e-7, or its
   frozen BOT solve has max(row residual, col residual) >= 1e-6, per the frozen
   residual criteria used in all previous rounds. Any such cell makes clause E fail;
   no silent acceptance, no re-solve.

End of amendment.

## 1. Confirmatory decoder-repair success (DECODER_REPAIR_CONFIRMED)

All of the following must hold:

- A. Δ_primary = F1(CONDITIONAL_UOT_D4) − F1(RAW_UOT_PLAN_D4) has its paired 95% CI
  entirely above 0 (macro), per the HOLDOUT_ANALYSIS_PLAN algorithm.
- B. The mechanistic co-primary directions agree: conditional decoding reduces the
  harmful-flip rates (row, column, split-child, merge-dst) and raises GT mutual-top5
  retention relative to RAW_UOT_PLAN_D4, in the same paired framework
  (operationalized in the Clarification amendment above).
  (Direction is required; the development magnitudes are not.)
- C. recovery_fraction >= 0.75; if the denominator (F1_cost − F1_rawUOT) <= 0, the
  pre-registered alternative applies: paired 95% CI of Δ_cost includes values
  >= −0.01 AND the paired 95% CI of Δ_primary excludes 0 positively.
- D. No catastrophic bridge-specific collapse: every bridge's paired Δ_primary mean is
  >= −0.005 (a bridge with a clearly negative, CI-excluding-zero reversal is handled
  by the HETEROGENEOUS_EFFECT rule below, which does NOT by itself fail this rule).
- E. No FP/FN explosion (conditional FP per template <= 3× raw; conditional FN per
  template <= 3× raw at the macro level), no implementation or solver failure, no NaN
  silently dropped (verification must catch).

If A–E pass: DECODER_REPAIR_CONFIRMED.

## 2. Transport-value classification (independent of the repair decision)

Using the secondary contrasts (macro paired CIs, same bootstrap):

- TYPE A — TRANSPORT RANKING REPAIRED AND POSITIVE TRANSPORT VALUE:
  DECODER_REPAIR_CONFIRMED AND Δ_support CI entirely above 0 AND Δ_cost CI entirely
  above 0.
- TYPE B — TRANSPORT RANKING REPAIRED BUT NO POSITIVE TRANSPORT VALUE:
  DECODER_REPAIR_CONFIRMED AND NOT TYPE A AND Δ_cost CI includes 0 or values >= −0.01
  (conditional stays at the cost ceiling without exceeding it).
- TYPE C — PARTIAL REPAIR: A and B pass but C fails (recovery_fraction < 0.75), or
  A passes but the mechanism direction B does not.
- TYPE D — FAILED REPAIR: A fails (CI not positive), or E fails.

TYPE classification and DECODER_REPAIR_CONFIRMED are two SEPARATE decisions: repair
can be confirmed even when no positive transport value exists (development = TYPE B).

## 3. UOT vs BOT (secondary; never a success condition)

If Δ_unbalanced CI includes 0 or is negligible (< 0.01): state that the independent
contribution of the unbalanced relaxation is not established on this clean benchmark.
If positive and CI excludes 0: report it, but do NOT turn it into a broad unbalanced-
transport superiority claim (no LEVEL upgrade from this contrast alone).

## 4. HETEROGENEOUS_EFFECT rule

If macro A–C pass but one bridge's paired Δ_primary CI is entirely below 0 (strong
reversal), the overall label is HETEROGENEOUS_EFFECT and the bridge-level results are
discussed one by one. This does not retroactively change the endpoint; it changes the
wording from "consistent across bridges" to "heterogeneous across bridges".

## 5. Claim mapping

The only wording allowed for the final holdout report is defined in
EXPECTED_CLAIM_MAPPING.md (written before holdout, containing conditional language and
no numbers). Any future manuscript edit requires separate human approval and must not
occur in the holdout execution round.
