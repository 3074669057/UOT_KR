# CONFIRMATORY_CLAIM_MAPPING.md

Post-result document for the one-shot confirmatory holdout (seeds 301–305). Generated
AFTER the verified execution, solely from the frozen outputs in
`out/multi_bridge_expansion/conditional_plan_holdout_results/`. This document is
ADDITIVE: the frozen preregistration package and its EXPECTED_CLAIM_MAPPING.md are
unchanged (hash-verified).

Authoritative inputs: `FINAL_CONFIRMATORY_HOLDOUT_REPORT.md`, `statistics.json`,
`verification.json`, raw per-cell artifacts. No alternative statistics were computed for
this mapping.

## SUPPORTED

- **Decoder repair confirmed.** All five preregistered gates (A primary paired Δ, B
  mechanism directions, C recovery, D bridge robustness, E safety/convergence) passed on
  the untouched holdout → DECODER_REPAIR_CONFIRMED.
- **Positive primary macro Δ.** Δ_primary = +0.075413, paired hierarchical 95% CI
  [0.070557, 0.080312], entirely above zero (RAW_UOT_PLAN_D4 0.2350 → CONDITIONAL_UOT_D4
  0.3104 macro edge F1).
- **Positive Δ on all three bridges.** Celer +0.0826 [0.0743, 0.0918]; Multichain +0.0820
  [0.0709, 0.0933]; PolyNetwork +0.0616 [0.0587, 0.0649]. Not driven by one bridge.
- **Preregistered mechanism directions all pass.** Harmful flip rates decrease (row
  −0.2595, column −0.2303, split-child −0.5360, merge-dst −0.5095) and GT mutual-top5
  retention increases (+0.2035), conditional minus raw, macro level.
- **Macro TYPE A transport-plan contribution.** Under the frozen macro classification
  rule, Δ_support = +0.0104 [0.0062, 0.0152] and Δ_cost = +0.0048 [0.0013, 0.0089] are
  both entirely above zero → positive transport-plan-level contribution beyond direct
  kernel/support decoding at the three-bridge macro level.

## NOT SUPPORTED

- **UOT-specific advantage over BOT.** Δ_bot ≈ −0.0003, 95% CI includes 0; no
  additional benefit attributable specifically to the unbalanced relaxation is established.
- **Unbalanced-relaxation-specific contribution.** The confirmed signal is
  transport-plan-level information beyond the kernel/support controls, not a contribution
  of the unbalanced mechanism itself.
- **Bridge-uniform TYPE A.** PolyNetwork's secondary contrasts are negative
  (Δ_cost −0.0043 [−0.0065, −0.0024]; Δ_support −0.0043 [−0.0065, −0.0024]); TYPE A is a
  macro classification only.
- **Universal superiority of RC-UOT-Q.** Not claimed from this experiment; existing
  baseline and scope limitations (Tables 2d/4/6/7) remain in force.
- **Causal claims beyond the preregistered diagnostics.** The mechanism metrics are
  observational, directional checks; they do not alone prove a complete causal
  decomposition of the OT solver.

## QUALIFIED

- **recovery_fraction = 1.0686.** Read only under the preregistered recovery metric
  (D = +0.070569 > 0): the conditional decoder slightly exceeded the amount-free cost
  reference. Do not phrase as "106.86% of lost performance recovered" or "more than
  complete recovery" without this qualification.
- **Development TYPE B vs holdout TYPE A.** The decoder-repair effect replicated; the
  transport-value classification strengthened from TYPE B (development, seeds 201–205) to
  TYPE A under the frozen holdout rule. Do not write "TYPE A replicated". Holdout criteria
  were fixed before seeds 301–305 were accessed; development and holdout were not pooled.
- **Poly secondary transport-value reversal.** Disclosed in full (above); reported as
  bridge-level heterogeneity of the secondary contrasts while the primary repair effect is
  positive on all bridges.
