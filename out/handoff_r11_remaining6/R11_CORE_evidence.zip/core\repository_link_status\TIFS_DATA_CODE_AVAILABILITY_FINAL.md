# TIFS_DATA_CODE_AVAILABILITY_FINAL.md

Data and code availability statement for "Non-One-to-One Cross-Chain Forensic Fund-Flow Correspondence: Transport Representation and Conditional Decoding" (IEEE TIFS submission).

## Code

- The Cross AML prototype (`tools/cross_aml/`) implements RPC evidence collection, flow construction, coverage qualification, RC-UOT-Q-style matching with abstention, and interpretable report generation. Dry-run mode requires no provider credentials.
- The frozen evaluation scripts (the hash-locked one-shot runner and the independently maintained verifier) and the hash manifests are part of the reproducibility package.

## Data

- Raw chain data are re-fetchable from public Ethereum and BNB Smart Chain nodes using the documented block ranges. Provider API keys are not released.
- The v4 data-only corpus (`tifs_temporal_external_v4/blocks/`) is prediction-blind, archived for provenance, with its frozen dataset hash manifest.
- Celer anchor/Validation labels used for benchmark construction derive from published Celer data; their redistribution terms are stated in the package.
- No off-chain identity or exchange-internal data are included.

## Release

Code and reproducibility materials will be provided upon acceptance/public release. The specific release address and the open-source license declaration will be supplied in the submission package.

---

*FINAL_SUBMISSION_AUTHOR_ACTION (not for the manuscript PDF): the authors must provide the release URL and license type before final submission; the manuscript PDF contains no TODO/TBD/placeholder URL (safe wording is used in Section V-J).*
