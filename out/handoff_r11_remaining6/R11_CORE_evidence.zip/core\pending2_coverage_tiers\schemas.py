"""Data schemas for Cross AML standalone tool."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

CoverageTier = Literal["A", "B", "C", "Uncovered"]
Decision = Literal["match", "non_match", "abstain", "diagnostic_candidate", "low_confidence_candidate"]


@dataclass
class EventRecord:
    chain: str
    tx_hash: str
    log_index: int
    block_number: int
    block_timestamp: int
    event_type: str
    contract_address: str
    from_address: str
    to_address: str
    token_address: str | None
    amount_raw: int
    decimals: int | None
    topics: list[str] = field(default_factory=list)
    data: str = ""
    bridge_protocol: str = "generic"
    transfer_key: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class Flow:
    flow_id: str
    chain: str
    tx_hashes: list[str]
    addresses: list[str]
    token_addresses: list[str]
    token_symbols: list[str]
    total_amount_raw: int
    amount_normalized_optional: float | None
    start_time: int
    end_time: int
    direction: str
    risk_seed_flag: bool
    evidence_refs: list[str] = field(default_factory=list)
    quotient_group_id: str | None = None


@dataclass
class PairFeatures:
    amount_consistency: float
    time_causality_score: float
    token_consistency: float
    path_consistency: float
    bridge_event_score: float
    transfer_key_match: float
    address_overlap_score: float
    risk_score_consistency: float
    group_ambiguity_score: float
    mass_diffusion_score: float
    evidence_score: float

    def as_dict(self) -> dict[str, float]:
        return {k: getattr(self, k) for k in self.__dataclass_fields__}


@dataclass
class CoverageDecision:
    covered: bool
    tier: CoverageTier
    evidence_score: float
    reasons: list[str]
    missing_evidence: list[str]
    high_confidence_allowed: bool


@dataclass
class MatchResult:
    source_flow_id: str
    destination_flow_id: str
    decision: Decision
    confidence: float
    coverage_tier: CoverageTier
    evidence_score: float
    match_score: float
    precision_oriented_score: float
    features: dict[str, float]
    evidence_refs: list[str]
    explanation: list[str]
    limitations: list[str]


@dataclass
class ToolInput:
    mode: Literal["pair_scoring", "candidate_discovery"]
    source_chain: str
    destination_chain: str
    source_tx_hashes: list[str]
    destination_tx_hashes: list[str] = field(default_factory=list)
    time_window_hours: float = 24.0
    token_filter: list[str] = field(default_factory=list)
    bridge_protocol: str = "generic"
