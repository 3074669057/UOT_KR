"""Human-readable explanations for match decisions."""
from __future__ import annotations

from cross_aml.schemas import CoverageDecision, MatchResult, PairFeatures


CLAIM_BOUNDARY_LINES = [
    "Output is an evidence-qualified AML investigation lead, not a legal conclusion.",
    "No full-scope high-P/R claim; uncovered edges are abstained.",
    "Not a claim of universal superiority over ABCTracer or Connector.",
    "Candidate discovery may be incomplete without indexer/archive node.",
]


def build_explanation(
    result: MatchResult,
    coverage: CoverageDecision,
    features: PairFeatures,
) -> MatchResult:
    lines: list[str] = []
    if result.decision == "match":
        lines.append("Match: event-backed coverage tier supports correspondence.")
        if features.transfer_key_match >= 0.85:
            lines.append("Strong transfer key / bridge identifier alignment.")
        if features.amount_consistency >= 0.7:
            lines.append("Amount consistency within configured tolerance.")
    elif result.decision == "abstain":
        lines.append("Abstain: insufficient evidence for high-confidence correspondence.")
        if coverage.missing_evidence:
            lines.append("Missing: " + ", ".join(coverage.missing_evidence))
    elif result.decision == "diagnostic_candidate":
        lines.append("Diagnostic candidate only (Tier C); requires investigator review.")
    elif result.decision == "low_confidence_candidate":
        lines.append("Low-confidence candidate; do not treat as confirmed match.")
    else:
        lines.append("Non-match: composite score below matching threshold.")

    lines.append(f"Coverage tier: {coverage.tier}; evidence_score={coverage.evidence_score:.3f}")
    lines.extend(CLAIM_BOUNDARY_LINES)
    result.explanation = lines + result.explanation
    result.limitations = list(dict.fromkeys(result.limitations + CLAIM_BOUNDARY_LINES[:2]))
    return result


def recommended_action(decision: str) -> str:
    mapping = {
        "match": "Prioritize manual review of bridge logs and beneficiary addresses.",
        "abstain": "Do not escalate solely on this pair; gather more chain evidence.",
        "diagnostic_candidate": "Use as weak lead only; corroborate with external data.",
        "low_confidence_candidate": "Queue for secondary review; not sufficient alone.",
        "non_match": "Deprioritize unless new evidence appears.",
    }
    return mapping.get(decision, "Review manually.")
