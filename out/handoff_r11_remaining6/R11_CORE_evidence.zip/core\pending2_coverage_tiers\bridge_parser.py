"""Generic and optional protocol-specific bridge event parsing."""
from __future__ import annotations

import re
from typing import Any

from cross_aml.schemas import EventRecord
from cross_aml.utils import sha256_short

DEPOSIT_HINTS = ("deposit", "send", "transferout", "lock")
WITHDRAW_HINTS = ("withdraw", "relay", "transferin", "release", "mint")

TRANSFER_ID_RE = re.compile(r"[a-f0-9]{8,64}", re.I)


def parse_bridge_events(
    chain: str,
    tx_hash: str,
    receipt: dict[str, Any],
    *,
    protocol: str = "generic",
    block_timestamp: int | None = None,
) -> list[EventRecord]:
    events: list[EventRecord] = []
    logs = receipt.get("log") if "log" in receipt else receipt.get("logs") or []
    for log in logs:
        extra = {k: v for k, v in log.items() if k not in ("topics", "data", "address")}
        ev = _parse_generic_bridge_log(chain, tx_hash, log, block_timestamp, extra)
        if ev:
            ev.bridge_protocol = protocol
            events.append(ev)
        if protocol == "celer" and protocol != "generic":
            celer_ev = _parse_celer_optional(log, chain, tx_hash, block_timestamp)
            if celer_ev:
                events.extend(celer_ev)
    return events


def _parse_generic_bridge_log(
    chain: str,
    tx_hash: str,
    log: dict[str, Any],
    block_timestamp: int | None,
    extra: dict[str, Any],
) -> EventRecord | None:
    topics = [str(t).lower() for t in (log.get("topics") or [])]
    if not topics:
        return None
    sig = topics[0]
    event_name = str(log.get("event_name") or extra.get("event_name") or _guess_event_name(sig, log)).lower()
    role = "unknown"
    for h in DEPOSIT_HINTS:
        if h in event_name or h in sig:
            role = "deposit"
            break
    for h in WITHDRAW_HINTS:
        if h in event_name or h in sig:
            role = "withdraw"
            break
    if role == "unknown" and not log.get("transfer_id") and not log.get("src_transfer_id"):
        return None

    transfer_id = log.get("transfer_id") or extra.get("transfer_id")
    src_transfer_id = log.get("src_transfer_id") or extra.get("src_transfer_id")
    if not transfer_id and not src_transfer_id:
        transfer_id, src_transfer_id = _extract_ids_from_data(str(log.get("data", "")))

    transfer_key = build_transfer_key(
        protocol="generic",
        src_chain=chain if role == "deposit" else "",
        dst_chain=chain if role == "withdraw" else "",
        transfer_id=str(transfer_id or src_transfer_id or ""),
        receiver=_topic_addr(topics, 2) or _topic_addr(topics, 1),
    )

    return EventRecord(
        chain=chain,
        tx_hash=tx_hash,
        log_index=int(str(log.get("logIndex", "0")), 16) if str(log.get("logIndex", "0")).startswith("0x") else int(log.get("logIndex", 0)),
        block_number=int(str(log.get("blockNumber", "0")), 16) if str(log.get("blockNumber", "0")).startswith("0x") else 0,
        block_timestamp=block_timestamp or 0,
        event_type=f"bridge_{role}",
        contract_address=str(log.get("address", "")).lower(),
        from_address=_topic_addr(topics, 1),
        to_address=_topic_addr(topics, 2),
        token_address=None,
        amount_raw=0,
        decimals=None,
        topics=topics,
        data=str(log.get("data", "")),
        transfer_key=transfer_key,
        extra={"event_name": event_name, "transfer_id": transfer_id, "src_transfer_id": src_transfer_id},
    )


def build_transfer_key(
    *,
    protocol: str,
    src_chain: str,
    dst_chain: str,
    transfer_id: str,
    receiver: str,
    token: str = "",
    amount_bucket: str = "",
) -> str:
    core = f"{protocol}|{src_chain}|{dst_chain}|{transfer_id}|{receiver.lower()}"
    if token or amount_bucket:
        core += f"|{token}|{amount_bucket}"
    return core


def _guess_event_name(topic0: str, log: dict[str, Any]) -> str:
    if log.get("event_name"):
        return str(log["event_name"])
    if "deposit" in topic0:
        return "Deposit"
    if "withdraw" in topic0:
        return "Withdraw"
    return "BridgeEvent"


def _extract_ids_from_data(data: str) -> tuple[str | None, str | None]:
    hexpart = data.replace("0x", "")
    try:
        raw = bytes.fromhex(hexpart[:128]).decode("utf-8", errors="ignore")
    except Exception:
        raw = hexpart
    m = TRANSFER_ID_RE.search(raw)
    if m:
        return m.group(0), m.group(0)
    return None, None


def _topic_addr(topics: list[str], idx: int) -> str:
    if len(topics) <= idx:
        return ""
    t = topics[idx]
    return ("0x" + t[-40:]).lower() if len(t) >= 40 else ""


def _parse_celer_optional(log: dict, chain: str, tx_hash: str, ts: int | None) -> list[EventRecord]:
    """Optional Celer-specific enrichment; generic parser remains primary."""
    return []
