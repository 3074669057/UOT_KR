# AUTHOR_METADATA_REQUIRED.md

作者元数据待补（SPS/TIFS initial submission 为 single-blind，正常包含作者身份）。

## 需要作者提供

1. **Names** —— 全部作者姓名（与 IEEE 会员号，如有）。
2. **Affiliations** —— 每位作者的单位（系/院/校/机构 + 城市 + 国家）。
3. **Corresponding author** —— 通讯作者标识。
4. **Email / contact** —— 通讯邮箱及期刊要求的联系方式。
5. 可选：ORCID、基金致谢、同等贡献声明。

## 当前状态

- `3/stage2/latex/main.tex` 与 `supplementary.tex` 的 \author 块为**内部占位**（Author~Names + thanks 注明由作者完成）。
- 因此当前 PDF **不是 final submission PDF**；状态为 READY_FOR_AUTHOR_FINAL_CHECK，作者补齐元数据并复编译后才可提交。
- 补充材料 PDF 同需作者名。

## 作者动作

1. 在 main.tex / supplementary.tex 中替换 \author 块为真实信息（或把信息提供给我，我代为填入并复编译）。
2. 复核编译后 PDF 首页作者块。
