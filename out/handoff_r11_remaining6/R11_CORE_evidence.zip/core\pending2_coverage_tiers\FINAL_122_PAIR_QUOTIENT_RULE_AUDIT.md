# FINAL_122_PAIR_QUOTIENT_RULE_AUDIT.md

TIFS packaging round. Date: 2026-09-05. Full provenance audit of the manuscript's
Table 3 result ("Coverage-qualified quotient inference": 122 covered holdout pairs,
44 positive / 78 negative, P/R/F1 1.000/1.000/1.000, AUROC/AUPRC 1.000/1.000,
ECE 0.000, event-backed projection coverage ≈0.792). All findings below come from
frozen repository artifacts (scripts + frozen outputs); no file was modified and no
experiment was run.

## 1. Answers to the mandated questions

1. **How the 122 pairs were produced.** Candidate quotient pairs are generated per
   source quotient class (phase20 `build_repaired_candidates`): "strong" candidates
   whose destination class shares the bridge transfer key; "near" candidates
   sharing `src_transfer_id`; up to 3 hard negatives and up to 8 random negatives.
   The covered-scope filter (phase24 `_covered_scope_pairs`) keeps a positive pair
   **only if its quotient key is already in `truth_clean`** and keeps negative
   pairs unconditionally. Splits: train 42–51, dev 52–71, holdout **212–231**
   (the 122 rows are the covered-scope holdout candidates).
2. **Ground-truth source.** Raw flow-pair labels (`synthetic_flow_labels.csv`) →
   `truth`; the quotient-level label is the derived `quotient_label =
   int(key in truth_clean)`, where `truth_clean` is the flow-pair truth aggregated
   into quotient classes.
3. **Method predictions? No.** The subset is defined by bridge-event evidence
   (decoded Send/Relay transferIds) plus label information (`truth_clean`); no
   method prediction participates in subset selection.
4. **Quotient construction.** Event-backed key =
   `celer_cbridge|1|56|<transferId>|<receiver>`; source classes group by the
   source event's `transfer_id`, destination classes by the destination event's
   `src_transfer_id`.
5. **Covered scope meaning.** A GT flow pair is covered iff both endpoints map to
   quotient classes with matching, non-empty transferIds.
6. **Independent of the label? NO.** See verdict below.
7. **Why no statistical inference.** n = 122 (44/78) is too small; the manuscript
   states this explicitly.
8. **The ≈0.792.** `event_backed_projection_coverage = len(covered_gt)/len(truth)`,
   computed on gate-reference seeds 52–57 (0.79167, rounded 0.792), and **carried
   over** into the holdout table rather than recomputed on 212–231; the
   full-scope claim gate FAILs on this value (< 0.80).

## 2. NON-CIRCULARITY VERDICT: FAIL (as an independent accuracy claim)

The frozen artifacts show the covered-pair label and the scoring rule are
co-defined on the same bridge-event transferId equality:

- Label: `tid_ok = str(src.transfer_id) == str(dst.src_transfer_id)` and
  `clean = tid_ok and len(gt_pairs) > 0` (phase20).
- Rule: the frozen model `Q-rule-bridge-key` scores exactly
  `bridge_transfer_key_exact_match` (transferId + receiver equality), threshold 1.0
  (phase25).
- On all 122 holdout rows, `quotient_label == bridge_transfer_key_exact_match`
  holds row-by-row; hence P/R/F1 = 1.000 by construction.

Therefore the 122-pair P/R/F1 = 1.000 is a **definitional consistency check on the
event-backed quotient projection**, not an independent correspondence-accuracy
measurement. The only genuinely independent label ingredient (GT flow-pair
existence) does not discriminate on the holdout (dev precision for the same rule
is 0.9845, showing it can weakly).

## 3. What was done to the manuscript (recorded, not silent)

The manuscript previously described the result as "zero-error covered-scope
inference." This packaging round replaced that framing (in §4.5, Table 3 caption,
§4.8 item 4, §5.1, and the Conclusion) with the consistency-check wording:

> both the covered-pair label and the rule are keyed on the same bridge-event
> transferId incidence, so this result is a definitional consistency check on the
> event-backed quotient projection … it carries no independent
> correspondence-accuracy interpretation.

This is a claim reframing mandated by the audit; no number changed.

## 4. AUTHOR_INPUT_NEEDED (submission-blocking decision for the authors)

An independent accuracy interpretation of the 122-pair result would require one of
(neither is present in the frozen repository):
1. an evaluation of the quotient rule against the original flow-pair ground truth
   with bridge-anchor signals masked; or
2. an explicitly non-bridge-event-derived label definition for the covered pairs.

Until the authors supply one of these (a NEW study, which the scientific freeze
forbids this round), the only permitted manuscript wording is the
consistency-check framing now in place. **Authors must explicitly approve the
consistency-check reframing** (AUTHOR_REVIEW_REQUIRED per mission §26), or
alternatively remove Table 3 from the main text entirely and relegate it to the
supplement as an internal machinery check.

## 5. Evidence pointers

- `scripts/run_phase20_quotient_integrity_repair.py` (key, `truth_clean`,
  `covered_gt`, coverage)
- `scripts/run_phase21_quotient_oracle_score_repair.py` (coverage expansion)
- `scripts/run_phase24_coverage_qualified_training_gate.py`
  (`_covered_scope_pairs`, splits, gates)
- `scripts/run_phase25_coverage_qualified_training.py` (`Q-rule-bridge-key`,
  holdout evaluation)
- `out/paper_full_pipeline_run/phase25_coverage_qualified_training/data/covered_holdout_pairs.csv`
  (the 122 rows; label ≡ rule identity)
- `out/paper_full_pipeline_run/phase25_coverage_qualified_training/holdout/quotient_holdout_claim_gate.json`
- `out/paper_full_pipeline_run/phase25_coverage_qualified_training/selection/selected_rcuot_q_covered.json`
  (dev precision 0.9845)
- `out/paper_full_pipeline_run/phase24_coverage_qualified_training_gate/diagnosis/phase24_coverage_qualified_training_gate.json`
  (coverage 0.79167 on 52–57)
- `out/paper_full_pipeline_run/phase24_coverage_qualified_training_gate/diagnosis/phase24_full_scope_claim_gate.json`
  (full-scope gate FAIL)
