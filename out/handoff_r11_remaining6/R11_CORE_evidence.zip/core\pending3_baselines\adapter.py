﻿# Connector adapter for open candidate pool
# Maps open-pool CSV column names to the args.* fields that Connector's
# WithdrawLocator expects. Must be run from D:\trae\tool\a\cross.
# Usage:
#   python D:\Edge\1\_connector_adapter\adapter.py
# This script reads the open-pool CSVs, applies column mapping,
# and saves Connector-compatible Parquet files for WithdrawLocator.

import pandas as pd
import sys, os

# --- Configuration ---
OPEN_POOL_DIR = "out/bsc_open_independent_v1"
# The two CSVs from the open pool protocol
SRC_CSV  = "data/in/Celer_ETH_cun.csv"      # source-chain transactions
DST_CSV  = "data/label/tx/Celer_BNB_qu.csv"  # destination-chain candidates

OUT_SRC  = f"{OPEN_POOL_DIR}/connector_adapter_src.parquet"
OUT_DST  = f"{OPEN_POOL_DIR}/connector_adapter_dst.parquet"

# --- Column mapping ---
# Connector.__init__ (dst_chain.py ~line 83) does:
#   src_txs.groupby(["args.srcChain", "args.dstChain"])
#   and requires: args.asset_s, args.receiver, args.amount, args.asset_d
#
# Connector.search_withdraw (~line 201) needs in dst_txs:
#   contractAddress, timestamp, txhash, from, to, value
#
# Open pool CSV columns:
#   Unnamed: 0, Net, Bridge, Address, id, hash, from, to,
#   value, timeStamp, blockNumber, symbol, contractAddress

SRC_RENAME = {
    "Net":              "args.srcChain",
    "Bridge":           "args.bridge",
    "hash":             "args.txhash",      # also keep as txhash for search_withdraw
    "from":             "args.sender",
    "to":               "args.receiver",
    "value":            "args.amount",
    "timeStamp":        "timestamp",
    "blockNumber":      "blockNumber",
    "symbol":           "args.symbol",
    "contractAddress":  "args.asset_s",
}

DST_RENAME = {
    "Net":              "args.srcChain",
    "Bridge":           "args.bridge",  
    "hash":             "args.txhash",
    "from":             "args.sender",
    "to":               "args.receiver",
    "value":            "args.amount",
    "timeStamp":        "timestamp",
    "blockNumber":      "blockNumber",
    "symbol":           "args.symbol",
    "contractAddress":  "args.asset_d",
}

def load_and_adapt(csv_path, rename_map, chain_tag, dst_chain_tag=None):
    """Load CSV, rename columns, add mandatory fields."""
    print(f"  Reading {csv_path} ...")
    df = pd.read_csv(csv_path)

    # Keep original columns that search_withdraw needs
    for col in ["hash", "from", "to", "value", "timeStamp", "blockNumber",
                "symbol", "contractAddress"]:
        if col in df.columns:
            df[f"_orig_{col}"] = df[col]

    # Apply rename
    df.rename(columns=rename_map, inplace=True)

    # Add mandatory args.* fields
    df["args.srcChain"] = df.get("args.srcChain", chain_tag)
    df["args.dstChain"] = df.get("args.dstChain", dst_chain_tag or chain_tag)

    # Ensure asset_d exists on source side (may be same as asset_s for Celer)
    if "args.asset_d" not in df.columns:
        df["args.asset_d"] = df.get("args.asset_s", "")

    # Ensure contractAddress survives for search_withdraw
    # (this is the column that was lost in cross-merge)
    if "contractAddress" not in df.columns:
        df["contractAddress"] = df.get("_orig_contractAddress", "")

    # Ensure txhash for search_withdraw
    if "txhash" not in df.columns:
        df["txhash"] = df.get("args.txhash", df.get("_orig_hash", ""))

    print(f"  Loaded {len(df)} rows, columns: {list(df.columns)[:8]}...")
    return df


def main():
    print("=== Connector Open-Pool Adapter ===")

    # Identify chain tags from filename conventions
    src_chain = "ETH"   # source CSV is Celer_ETH_cun.csv
    dst_chain = "BNB"   # destination CSV is Celer_BNB_qu.csv

    # --- Source side ---
    print("\n[1/2] Adapting source transactions ...")
    src_df = load_and_adapt(SRC_CSV, SRC_RENAME, src_chain)

    # --- Destination side ---
    print("\n[2/2] Adapting destination candidates ...")
    dst_df = load_and_adapt(DST_CSV, DST_RENAME, dst_chain)

    # --- Save ---
    os.makedirs(OPEN_POOL_DIR, exist_ok=True)
    src_df.to_parquet(OUT_SRC, index=False)
    dst_df.to_parquet(OUT_DST, index=False)

    print(f"\n  Source saved:  {OUT_SRC}  ({len(src_df)} rows)")
    print(f"  Dest   saved:  {OUT_DST}  ({len(dst_df)} rows)")
    print("\nAdapter complete. Now load these Parquet files into Connector:")
    print(f"  src_txs = pd.read_parquet('{OUT_SRC}')")
    print(f"  dst_txs = pd.read_parquet('{OUT_DST}')")
    print("  locator = WithdrawLocator(src_txs, dst_txs, dst_chain='BNB')")

if __name__ == "__main__":
    main()
