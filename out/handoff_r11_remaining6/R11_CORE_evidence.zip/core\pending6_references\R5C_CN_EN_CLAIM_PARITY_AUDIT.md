# R5C_CN_EN_CLAIM_PARITY_AUDIT.md

R5C round. Date: 2026-09. Scope: claim-level parity between the CN master
DOCX (`ZN_TIFS_CN_R5_DRAFT.docx`) and the EN manuscripts
(`draft/en/full_manuscript_final.md`, `04_experiments.md`, Supplements
S.1–S.4). Method: mechanical keyword presence check per claim in both
language surfaces (23 claims), plus cross-reference checks on the EN files.

## 1. Parity results — 23/23 PASS

| Claim | CN | EN |
|---|---|---|
| Title (运输表示与条件解码 / Transport Representation and Conditional Decoding) | ✓ | ✓ |
| Edge-inclusion 0.946 / 0.967 with qualifier | ✓ | ✓ |
| Strict exact-topology zero | ✓ | ✓ |
| Threshold-MM dominance 0.120–0.168 | ✓ | ✓ |
| Δ_primary +0.075413, frozen CI [0.070557, 0.080312] | ✓ | ✓ |
| Sensitivity CIs [0.0677, 0.0831] / [0.0676, 0.0849] / [0.0708, 0.0803] | ✓ | ✓ |
| v4 audit: 2,451 units, share 0.371277, merge 85 | ✓ | ✓ |
| v5 audit: 5,516 units, share 0.6200, merge 76 | ✓ | ✓ |
| Conservative G = 2 both windows | ✓ | ✓ |
| External performance unestablished | ✓ | ✓ |
| Paper-facing naming (UOT / UOT-Q; legacy RC-UOT identifier note) | ✓ | ✓ |
| Baseline downgrade (representation controls) + asymmetry disclosure | ✓ | ✓ |
| Degree>5 representational limit | ✓ | ✓ |
| Bounded scalability wording | ✓ | ✓ |
| Prediction-blind audits, no method execution | ✓ | ✓ |

No core claim exists in only one language version.

## 2. Cross-reference results

- EN main: Table references {1,2,4,5,6,7,8} — Table 3 dangling references:
  **0** (fixed in R5B; re-verified).
- Figure references {1,5,6,7}; the 122-pair table appears only in
  Supplement S.1.
- Supplement references S.1–S.4 all resolve to files
  (`supplement_S1_covered_quotient.md`, `supplement_S2_ci_sensitivity.md`,
  `supplement_S3_provenance_adequacy.md`, `supplement_S4_scalability.md`).
- Fig.4 caption matches the repaired figure (edge-inclusion labels; strict-
  zero note moved to the figure bottom margin).
- v4/v5 merged Table 8 (EN) and 表 4 (CN) carry identical values, both
  sourced from the frozen audit artifacts.

## 3. Status

- CN_EN_CLAIM_PARITY: **PASS**
- REFERENCE_QC: **PASS** (R5B fixes retained: [28] RAID 2024 four authors,
  CONNECTOR DOI 10.1109/TIFS.2025.3588249, FATF specific URL, ABCTracer
  naming; re-checked this round).
