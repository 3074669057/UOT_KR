# HOLDOUT_PREREGISTRATION.md

Date: 2026-09-02 (Asia/Shanghai). DESIGN-ONLY document: no holdout data exists, none was
generated, none was read. This file identifies the future confirmatory holdout and the
already-locked candidate. All hashes are managed EXTERNALLY in `HASH_MANIFEST.json`; no
spec stores its own SHA.

## 1. Candidate identity (ALREADY LOCKED — not rewritten here)

- Candidate spec: `out/multi_bridge_expansion/conditional_plan_candidate_dev/CONDITIONAL_PLAN_CANDIDATE_SPEC.md`
- Full SHA256 (authoritative in the manifest): `0f360addc1f2a220299d75b4aa9cad1ee1e504e8097ae5bacfc0da40542cc401`
- Formula (recalled for convenience; the locked spec is authoritative):
  r_i = sum_j P_ij ; c_j = sum_i P_ij ;
  S_row(i,j) = P_ij / c_j ; S_col(i,j) = P_ij / r_i ;
  D4 mutual-rank: row rank(S_row) <= 5 AND column rank(S_col) <= 5.
  Zero realized-mass endpoints: no support (ranked last); plain float64; no tunable
  epsilon. Nothing in the candidate definition may change.

## 2. Confirmatory holdout identity

- seeds: 301, 302, 303, 304, 305 (NEVER generated/read as of this writing)
- bridges: Celer, Multichain, PolyNetwork
- templates: 48 per seed (same generator/template definitions as development)
- The holdout must use EXACTLY the same: faithful generator, flow-anchor construction,
  GT semantics, template definitions, noise construction, feature pipeline, amount-free
  renormalized pairwise cost (frozen weights), risk/evidence-weighted marginals,
  reg=0.05, reg_m=0.5, all other frozen UOT parameters, D4 k=5, and the
  conditional-plan formula.
- NO bridge-specific parameters, NO seed-specific parameters, NO holdout-dependent
  filtering.

## 3. Preregistered methods (exactly five; no additions after holdout)

A. RAW_UOT_PLAN_D4       (frozen current RC-UOT-Q decode)
B. CONDITIONAL_UOT_D4    (PRIMARY candidate)
C. AMOUNT_FREE_COST_D4   (cost ceiling reference)
D. CONDITIONAL_BOT_D4    (transport-family control)
E. SUPPORT_PLUS_K_D4     (support + kernel ranking, as previously defined)

No new decoder, no new normalization, no k tuning, no threshold tuning. Historical
Connector/ABCTracer/Threshold-MM results are separate discussion material only and may
not alter this preregistration.

## 4. Primary confirmatory hypothesis

PRIMARY: CONDITIONAL_UOT_D4 improves correspondence ranking over RAW_UOT_PLAN_D4.
Primary endpoint: macro edge F1 across the three bridges.
Primary contrast: Δ_primary = F1(CONDITIONAL_UOT_D4) − F1(RAW_UOT_PLAN_D4),
direction preregistered Δ_primary > 0, evaluated PAIRED (identical bridge × seed ×
template instances for every method).

## 5. Mechanistic co-primary criteria

Performance alone is insufficient. The holdout must also show, in the same paired
framework, that conditional decoding reduces the dual-scaling harmful-flip phenomenon
relative to RAW_UOT_PLAN_D4:
- row harmful flip rate (K → plan mutual-top5 exits)
- column harmful flip rate
- split-child harmful flip rate
- merge-dst harmful flip rate
- GT mutual-top5 retention
Confirmatory interpretation requires the PERFORMANCE direction and the MECHANISM
direction to agree. The exact development percentages are NOT required to reproduce.

## 6. Recovery criterion (threshold frozen at development time)

recovery_fraction = (F1_conditional − F1_rawUOT) / (F1_cost − F1_rawUOT).
Primary mechanism-success threshold: recovery_fraction >= 0.75 (unchanged).
Degenerate-denominator rule (fixed NOW): if (F1_cost − F1_rawUOT) <= 0 in holdout,
recovery_fraction is NOT computed; criterion C (see HOLDOUT_DECISION_RULES.md) is then
evaluated by the alternative rule: the paired 95% CI of Δ_cost must include values
>= −0.01 AND the paired 95% CI of Δ_primary must exclude 0 in the positive direction.

## 7. Secondary comparisons (classification only; cannot be promoted to primary later)

- Δ_cost = F1(CONDITIONAL_UOT_D4) − F1(AMOUNT_FREE_COST_D4): repair-replication vs
  possible transport value vs incomplete repair. NOT a success requirement.
- Δ_support = F1(CONDITIONAL_UOT_D4) − F1(SUPPORT_PLUS_K_D4): decides TYPE A/B/C/D.
- Δ_unbalanced = F1(CONDITIONAL_UOT_D4) − F1(CONDITIONAL_BOT_D4): secondary; UOT
  superiority is NOT a required success condition.

## 8. Statistical and decision content

Frozen in `HOLDOUT_ANALYSIS_PLAN.md` (aggregation/bootstrap algorithm, RNG seed,
replicates, multiple-comparison hierarchy, bridge consistency) and
`HOLDOUT_DECISION_RULES.md` (success tree, DECODER_REPAIR_CONFIRMED vs TYPE A/B/C/D,
HETEROGENEOUS_EFFECT). Neither may change after holdout observation.

## 9. Integrity / provenance

The entire preregistration package (this file, HOLDOUT_ANALYSIS_PLAN.md,
HOLDOUT_DECISION_RULES.md, EXPECTED_CLAIM_MAPPING.md, the future runner and verifier
scripts) is SHA256 hash-locked in the external HASH_MANIFEST.json together with the
candidate-spec reference, git commit/diff status, timestamp, and the Python/POT
environment versions. The future runner refuses to execute unless every hash verifies.

## 10. Status

HOLDOUT_PREREGISTRATION_READY_FOR_HUMAN_APPROVAL (design only; 301-305 untouched).
