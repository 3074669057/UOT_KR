# TIFS_COVER_LETTER_FINAL.md

Date: [author completes]

To the Editor-in-Chief,
IEEE Transactions on Information Forensics and Security

Dear Editor,

We submit the manuscript "Non-One-to-One Cross-Chain Forensic Fund-Flow Correspondence: Transport Representation and Conditional Decoding" for consideration as a regular paper in IEEE Transactions on Information Forensics and Security.

**Forensic relevance.** Cross-chain money laundering fragments suspicious asset trails across bridges, tokens, and blockchains. Regulators and industry intelligence now treat chain-hopping, small-amount splitting, and cross-bridge aggregation as established laundering typologies, yet the tooling available to investigators remains largely transaction-level and one-to-one. The central problem this paper addresses is that fund-flow correspondence in cross-chain forensics is not always one-to-one: one source-chain flow may fan out to several destination-chain flows, and several source flows may consolidate into one destination flow.

**The non-one-to-one correspondence problem.** We formalize Cross-Chain Suspicious Fund-Flow Correspondence (CSFFC) as a flow-level, mass-bearing soft-correspondence problem, and show that raw transport-plan values are not pure correspondence affinities---their rankings are distorted by transport scaling and marginal pressure.

**Ranking-distortion diagnosis and repair.** We diagnose this distortion, propose directional conditional decoding with an exact dual-cancellation analysis (stated as a direct corollary of standard Sinkhorn structure, not as a new normalization), and validate the repair in a preregistered, hash-locked, one-shot confirmatory holdout on untouched seeds across three bridges (Celer, Multichain, PolyNetwork): macro edge F1 rises from 0.2350 to 0.3104, primary effect +0.075413 with paired 95% CI [0.070557, 0.080312], positive on every bridge, with all five preregistered mechanism-direction indicators in the repair direction and an independent verifier recomputing every result.

**Transparent external-validity boundary.** We also report transparently what the work does not establish: strict exact-topology recovery remains zero for every tested method at the frozen decode; a calibrated threshold rule dominates edge F1; the confirmatory experiment does not establish an unbalanced-relaxation-specific advantage (balanced vs. unbalanced conditional decoding differ by -0.0003 with a CI including zero); and an independent post-development temporal data audit (data-only, prediction-blind) confirms that real flow-level fan-out structure exists outside the development corpus but did not meet the preregistered adequacy gate (G = 7 < 8), so no method was executed on it and no external-performance claim is made. The v3 external-execution failure and the decision not to rerun are disclosed in full in the experimental provenance section.

**Materials.** The submission includes the main manuscript, a supplementary document (coverage-qualified quotient diagnostic, fixed-delay anchor audit, Connector native diagnostic, baseline parameter provenance, metric definitions, confirmatory protocol, external-validation history, reproducibility hashes), 41 verified references, and the reproducibility package description.

We confirm that this manuscript has not been published previously and is not under consideration elsewhere. All authors have approved the submission.

Sincerely,
[Author names, affiliations, contacts — completed by the authors]

---

*Notes for the authors (not part of the letter): this letter deliberately does not claim external real-world method performance confirmed. Author block, date, and contacts must be completed before submission.*
