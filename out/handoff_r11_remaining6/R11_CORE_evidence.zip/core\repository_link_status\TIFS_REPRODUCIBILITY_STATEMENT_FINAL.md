# TIFS_REPRODUCIBILITY_STATEMENT_FINAL.md

Reproducibility statement for "Non-One-to-One Cross-Chain Forensic Fund-Flow Correspondence: Transport Representation and Conditional Decoding" (IEEE TIFS submission).

## Confirmatory holdout

- Seeds 301--305 (Celer, Multichain, PolyNetwork; 48 templates per seed; 720 paired template instances) form the confirmatory decoder-repair holdout. They are permanently sealed: hash-locked, one-shot, untouched, and never rerun.
- Every confirmatory number (Table VI and the strict-evaluator recomputation of Table V) was produced by a hash-locked one-shot runner whose hash manifest pins the frozen candidate (sha256 0f360addc1f2a220299d75b4aa9cad1ee1e504e8097ae5bacfc0da40542cc401), the decoder (k = 5), reg = 0.05 / reg_m = 0.5, cost weights, marginals, tau = 0.478 (structural protocol), the paired bootstrap (B = 4,000, RandomState(20240101)), and the decision rules.
- A separately maintained verification script recomputes all statistics from the raw per-cell artifacts and matches the runner within 1e-9.

## External-validation history (disclosed, not hidden)

- **v3:** a preregistered Level-I external execution entered the prediction path and failed before valid performance (missing import itertools; zero-marginal solver-domain defect producing NaN plans). Execution count = 1, permanently closed: no rerun, no valid performance.
- **Solver-interface repair:** support-aware wrappers (reduce to the positive-marginal support) are mathematically equivalent (the KL-unbalanced objective is infinite for positive mass on a zero-reference row/column) and were validated only on non-test data (15/15 development cells, 0.0 plan difference, 0 decoder discrepancies; 8/8 zero-support constructed tests). The repair was never applied to the v3 corpus and never used to produce any performance number.
- **v4:** a new disjoint, prediction-blind Level-I corpus (2024-05-20T00:00:00Z--2025-05-19T00:00:00Z; protocol-native linkage Send.transferId == Relay.srcTransferId; disjointness verified against 359,256 historical transaction identities with zero intersections) was assembled data-only. DATA ADEQUACY FAIL (G = 7 < 8): no method executed, no performance claim, statistical branch NOT_EVALUABLE. The corpus is archived for provenance only.
- The external-validation experiment line is closed for this submission (no v5).

## Frozen artifacts

All frozen artifacts referenced in the paper belong to the accompanying reproducibility package: the Cross AML prototype (tools/cross_aml/, dry-run mode requires no provider credentials), the frozen evaluation scripts (one-shot runner and independent verifier), the hash manifests, the frozen confirmatory artifacts (conditional_plan_holdout_results/), the v3 failure package and quarantined blocks, and the v4 data-only corpus (tifs_temporal_external_v4/blocks/, prediction-blind, with its frozen dataset hash manifest). Raw chain data are re-fetchable from public Ethereum and BNB Smart Chain nodes using the documented block ranges; provider API keys are not released. Celer anchor/Validation labels derive from published Celer data; redistribution terms are stated in the package.
