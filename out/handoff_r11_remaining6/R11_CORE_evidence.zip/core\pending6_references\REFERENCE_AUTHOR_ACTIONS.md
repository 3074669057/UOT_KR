# REFERENCE_AUTHOR_ACTIONS.md

引用同步最终记录（作者决定轮更新；上一版状态已被本轮逐条处置取代）。
引用权威：`3/references/references.bib`（41 条，已按作者决定清理）。

## 1. 本轮逐条处置结果（原 7 UNVERIFIABLE + 1 AUTHOR_REVIEW_REQUIRED）

| 原条目 | 原状态 | 本轮处置 | 处置依据 |
|---|---|---|---|
| qin2022rise | AUTHOR_REVIEW_REQUIRED | **VERIFIED，保留** | 现条目（Qin/Zhou/Gervais, Quantifying Blockchain Extractable Value, IEEE S&P 2022）经 IEEE 记录与 arXiv:2101.05511 双源确认；原引用标题不存在，替换为已确认文献 |
| thibodeau2022celer | UNVERIFIABLE | **VERIFIED，保留（URL 引用）** | Celer cBridge 官方文档站 https://cbridge-docs.celer.network/ 在线确认 |
| harvey2020cryptocurrency | UNVERIFIABLE | **REMOVE** | 无法确认；§2.1 列表式支撑引用，非主线 |
| loesch2019towards | UNVERIFIABLE | **REMOVE** | 无法确认；非主线 |
| khalil2018iotc | UNVERIFIABLE | **REMOVE** | 无法确认；非主线 |
| kipp2021taint | UNVERIFIABLE | **REMOVE** | 无法确认；非主线 |
| liu2022compliance | UNVERIFIABLE | **REMOVE** | 无法确认；非主线（正文语句保留 arrieta2020explainable 支撑） |
| chen2019reproducibility | UNVERIFIABLE | **REMOVE** | 无法确认；非主线（复现性句保留 pineau2021improving + lamprecht2019research） |

- **AUTHOR_INPUT_REQUIRED（重要 prior art 无法确认）= 0。**
- 参考文献总数：47 → **41**。正式参考文献列表与正文中内部标签（UNVERIFIABLE/FAILED/TODO/AUTHOR_REVIEW_REQUIRED）= **0**（QA 程序化确认）。

## 2. 投稿时（Stage 2 导出前）需在出版方页面人工确认的 PARTIALLY_VERIFIED 条目（照旧）

1. lin2025connector：DOI 10.1109/TIFS.2025.3561234、卷 20、页 7588–7601（IEEE Xplore doc 11080119）；arXiv:2409.04937。
2. zheng2025abctracer：第一作者（Lin vs Zheng）与完整作者顺序（arXiv 2504.01822）。
3. wang2022tracer（TRacer）：完整作者列表/顺序与 TIFS 卷页（DOI 10.1109/TIFS.2023.3266162 已确认）。
4. weber2019amlbitcoin：如引用 KDD ADF workshop 版，补会议 DOI/页码。
5. monamo2016unsupervised：DOI 10.1109/AFRCON.2016.7535464 解析确认。
6. nadarajah2018characterizing：最终载体（arXiv 1810.11956 vs ICDM Workshops）。
7. reid2011analysis：2011 会议版 vs 2013 Springer 章节版。
8. fatf2021updatedguidance：替换为 FATF 具体页面 URL。
9. 键名-年份外观性不一致（apostolaki2019hijacking/benamou2014iterative/sejourne2019sinkhorn/chen2021phishing）：可选重命名键。

## 3. 随附作者确认项（非阻断）

- qin2022rise：请作者确认"Quantifying Blockchain Extractable Value"（S&P 2022）即为原意所指文献（无异议则无需任何改动）。见 `3/final/FINAL_AUTHOR_BLOCKERS.md` 第 3 项。

## 4. 已删除条目留档

- eberle2021aphrodite（上一轮已删）+ 本轮 6 条（harvey/loesch/khalil/kipp/liu2022compliance/chen2019reproducibility）：删除记录与依据见本文 §1 及冻结的 FINAL_REFERENCE_VERIFICATION_REPORT.md。
