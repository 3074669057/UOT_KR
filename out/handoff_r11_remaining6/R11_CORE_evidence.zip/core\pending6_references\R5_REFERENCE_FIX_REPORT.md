# R5_REFERENCE_FIX_REPORT.md

R5 TIFS scientific repair. Date: 2026-09 (R5 round). Scope: bibliography
re-verification and rendering-defect repair. Method: nature-ref-verifier +
nature-citation workflows applied manually (skill tool had no live
registration; SKILL.md files read from `skills/nature-skills/`). Sources:
Crossref API, IEEE Xplore records, arXiv API, proceedings.neurips.cc metadata,
usenix.org, BMVC official proceedings, publisher pages. NO content farms. No
metadata was invented; unverifiable fields are marked.

## 1. Totals (authoritative list = the 48-entry R4 DOCX bibliography)

| Status | Count |
|---|---|
| VERIFIED_R5 (re-verified externally this round) | 26 |
| VERIFIED_PRIOR (prior-round record, no defect found) | 16 |
| FIX_METADATA (metadata or rendering defect) | 11 |
| AUTHOR_INPUT_NEEDED | 1 |
| Total | 48 (note: 5 FIX_METADATA rows are pure rendering defects, see §3) |

Reconciliation with the prior report (item L of the gap matrix): the prior
"48-entry" status totals described `out/paper_full_pipeline_run/
manuscript_final/references.bib`, which is NOT the list shipped in the R4
DOCX. The DOCX dropped 7 entries (6 UNVERIFIABLE + eberle2021aphrodite) and
added 7 new entries (ETTracker, wavelet-AML SciRep, ICAIF subgraph, FedGNN
IoT-J, eCrime Dark Art, BMVC GWOT, SilentLedger). The DOCX is the reference
of record for R5; the bib file must be synced to it (listed in §5).

## 2. Metadata corrections (authoritative findings)

1. **[4] CONNECTOR — DOI was invalid.** `10.1109/TIFS.2025.3561234` does not
   resolve (doi.org "DOI Not Found"). Correct DOI:
   `10.1109/TIFS.2025.3588249` (resolves to IEEE Xplore). Volume/pages
   (20:7588–7601) and author list confirmed.
2. **[5] "Track and Trace" metadata correct; ABCTracer naming unresolved**
   — no paper titled "ABCTracer" was found on Crossref/arXiv; the entry is
   the TSC paper (18(6):4291–4303, DOI 10.1109/TSC.2025.3618729). See §4
   naming decision.
3. **[13] SuperGlue pages** — dual official pagination: IEEE Xplore
   4937–4946 vs CVF open-access 4938–4947. For an IEEE manuscript use
   4937–4946 (DOCX already correct; bib was wrong).
4. **[40] LoFTR pages** — IEEE 8918–8927 vs CVF 8922–8931. Use IEEE
   8918–8927 (DOCX already correct; bib was wrong).
5. **[31] Apostolaki DOI** — correct is `10.1109/SP.2017.29`;
   `SP.2017.59` is a different paper (Lever et al.). DOCX correct; bib wrong.
6. **[18] Monamo venue** — ISSA 2016 pp. 129–134, DOI
   `10.1109/ISSA.2016.7802939` (DOCX correct; bib's AFRICON + wrong DOI must
   be fixed).
7. **[32] Yousaf pages 837–850** (usenix.org official BibTeX) — add to DOCX.
8. **[22] Hamilton pages 1024–1034** (NeurIPS official metadata) — add.
9. **[12] Rocco pages 1651–1662** (NeurIPS official metadata) — add.
10. **[7] Weber ADF 2019** — pages/DOI UNVERIFIABLE (workshop paper); cite
    arXiv:1908.02591 only, do not print a page range.
11. **[28] Cross-chain bridges SoK is published** at RAID 2024, pp. 298–316,
    DOI `10.1145/3678890.3678894`. The published version drops "SoK:" from
    the title and drops author Josh Barbee (4 authors). DOCX cites the arXiv
    version with an empty venue — fix by citing the RAID published version
    (+ arXiv note), or keep arXiv explicitly labeled as preprint. Harness
    recommendation: cite the RAID published version (venue credibility) with
    the arXiv id in a note.
12. **[33] Sarkhosh — upgrade** from arXiv-only to the published APWG eCrime
    2025 proceedings (pp. 1–18, DOI `10.1109/eCrime66972.2025.11327832`),
    keep arXiv:2509.21831 as note.
13. **[20] ETTracker / [25] Scientific Reports** — "128900" and "1548" are
    ARTICLE NUMBERS, not page ranges; render as "vol. 296, Art. no. 128900"
    / "vol. 16, Art. no. 1548".
14. **[42] FATF 2021** — replace the generic URL with the specific page:
    https://www.fatf-gafi.org/en/publications/Fatfrecommendations/Guidance-rba-virtual-assets-2021.html
    (verified this round).
15. **[1][2][3][9][14][15][17][19][21][23][24][26][27][29][30][34][38][43]
    [44][45][46][47][48]** — re-verified or prior-verified with no defect.

## 3. Rendering defects found in the R4 DOCX (the "metadata verified" vs
"rendered correct" gap)

| Ref | Defect |
|---|---|
| [10] | Author list MISSING (renders ". Unbalanced Optimal Transport…") |
| [12] | Author list MISSING |
| [16] | Author list MISSING |
| [36] | Author list MISSING |
| [39] | Author list MISSING |
| [11] | Literal LaTeX escape "C\'edric" |
| [35], [37] | Literal LaTeX escape "Peyr\'e" |
| [17], [29], [30] | Literal LaTeX escape "S\&P" |
| [28] | Empty venue field (", 2023.") |
| [22], [32] | Missing pages |
| [42] | Generic FATF URL |

These five missing-author entries correspond exactly to bib entries whose
author field contains accented names (Chizat Lénaïc, Séjourné Thibault,
Vialard François-Xavier, Peyré Gabriel) plus two plain-name entries — the
DOCX bibliography builder dropped the author list for these entries. The fix
restores the author strings with correct Unicode (é, ï, ç) and removes the
leaked LaTeX escapes.

## 4. ABCTracer naming decision (RESOLVED this round)

Facts: (a) the manuscript names the second one-to-one baseline "ABCTracer"
citing @zheng2025abctracer; (b) bibliography entry [5] is the TSC paper
"Track and Trace: Automatically Uncovering Cross-Chain Transactions in the
Multi-Blockchain Ecosystems"; (c) full-text verification of arXiv:2504.01822
confirms the paper's system IS named **ABCTRACER** ("This paper proposes
ABCTRACER, an automated, bi-directional cross-chain transaction tracing
tool..."), appearing four times in the abstract; the title "Track and Trace"
is the paper title, not the system name; (d) the arXiv search all:ABCTracer
returns exactly this one paper (no standalone ABCTracer paper exists).

Decision: **keep "ABCTracer"** as the baseline name (system name introduced
in [5]); harmonize the casing to ABCTRACER where the paper's own name is
used, and keep the mandatory "-style" suffix (the baseline is an adapted
diagnostic, not an original-system run). The citation key zheng2025abctracer
(first author Lin) is a cosmetic key-author mismatch; keep the key for
citation stability and add the note. No baseline rename is required.

## 5. Bib-sync actions (references.bib, package level)

APPLIED this round (recorded, not silent): `out/paper_full_pipeline_run/
manuscript_final/references.bib` synced to the verified 48-entry DOCX set —
CONNECTOR DOI fixed; Monamo → ISSA 2016 with pages/DOI; Apostolaki DOI fixed;
SuperGlue/LoFTR pages set to IEEE pagination; Yousaf/Hamilton/Rocco pages
added; Huang S&P 2018 pages/DOI added; Chen IJCAI pages/DOI added; Zhou SoK
pages/DOI added; Qin pages/DOI added; cross-chain-bridges SoK upgraded to the
RAID 2024 published version; FATF 2021 specific URL; the 7 DOCX-new entries
added (ETTracker, wavelet-AML, ICAIF subgraph, FedGNN IoT-J, eCrime Dark Art
with eCrime DOI, BMVC GWOT, SilentLedger); the 6 UNVERIFIABLE entries
commented out (removed from the shipped list). Pre-sync hash
`07044E8174A3E3A573CC37D1F9FB89B4344C334C252F5A601EBCBA541C77016C` (matches
the FINAL_TIFS_MANUSCRIPT_LOCK record); post-sync hash
`CB16BFA4599E453BCDF868929CE966FF1A8A826E43BD27D64E1690A7DB590F80`; 48
active entries.

## 6. DOCX repair status

- Applied to the R5 copy: `3/chinese_rewrite_r5/draft/` (the R4 DOCX is
  untouched). Render verification: no Word/LibreOffice available in this
  environment, so the rendered check = full text re-extraction of the saved
  DOCX (all 48 entries present, authors restored, escapes gone, DOIs
  resolve); a human visual pass over the reference page is still required at
  packaging time (accented glyphs, line wrapping).

## 7. Author actions required

1. Confirm the CONNECTOR DOI replacement (item 2.1).
2. Decide the ABCTracer / Track-and-Trace naming (item 4).
3. Choose arXiv-preprint vs RAID-published citation for the cross-chain
   bridges SoK (item 2.11; recommendation: RAID).
4. Confirm the FATF 2021 URL (item 2.14).
