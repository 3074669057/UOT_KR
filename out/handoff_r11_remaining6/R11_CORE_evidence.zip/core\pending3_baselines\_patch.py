﻿import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

with open(r"D:\Edge\1\_latex_extracted\main.tex", "r", encoding="utf-8") as f:
    content = f.read()

patches_applied = 0

# Strategy: find by start/end markers and extract the exact text between them

# --- Binary failure passage ---
start_marker = "Connector's failure mode is essentially binary."
end_marker = "no transitional region between the two."

idx_start = content.find(start_marker)
idx_end = content.find(end_marker)

if idx_start >= 0 and idx_end >= 0:
    idx_end += len(end_marker)
    old_text = content[idx_start:idx_end]
    new_text = (
        "Connector's failure mode is structurally binary---a consequence of its "
        "transaction-level, field-dependent matching logic. "
        "When only the identity- and event-anchoring fields (event, bridge, sender) are removed, "
        "performance is nearly unchanged (F1 0.9736), because these fields do not enter "
        "WithdrawLocator's core matching columns. "
        "Once required matching fields such as receiver or dstChain are missing, however, "
        "Connector is directly blocked for lack of deployment-critical information "
        "(recorded as N/A, not F1 = 0); if fields such as amount, asset_s, or timestamp "
        "are zeroed or masked, it collapses to zero prediction (F1 = 0.0000). "
        "There is no transitional region between these states---Connector either runs "
        "at full strength or fails entirely."
    )
    content = content.replace(old_text, new_text)
    patches_applied += 1
    print("Patch: Binary failure (len={})".format(len(old_text)))
else:
    print("Binary failure markers not found: start={}, end={}".format(idx_start, idx_end))

# --- Graded degradation passage ---
start_marker2 = "EC-UOT-Q instead exhibits a markedly different, graded degradation:"
end_marker2 = "no transaction-level anchor leakage."

idx_start2 = content.find(start_marker2)
idx_end2 = content.find(end_marker2)

if idx_start2 >= 0 and idx_end2 >= 0:
    idx_end2 += len(end_marker2)
    old_text2 = content[idx_start2:idx_end2]
    new_text2 = (
        "EC-UOT-Q instead exhibits graded degradation: "
        "when the masked field does not enter its core cost terms, performance is barely affected, "
        "with joint F1 remaining stable at approximately 0.70 after removing receiver, dstChain, "
        "asset_s, or timestamp; once the highest-weighted amount dimension is masked, "
        "F1 drops smoothly to 0.3714, and drops further to 0.1431 when timestamp is additionally masked. "
        "In the extreme case where bridge metadata and core observable fields are all absent, "
        "EC-UOT-Q still runs and outputs auditable candidates, with recovery capability reduced "
        "to approximately 0.0108. Across all 34 masking levels---not merely the representative subset "
        "shown in Table~\\ref{tab:masking_degradation}---EC-UOT-Q's tx-CVR remains 0 throughout, "
        "confirming the absence of no transaction-level anchor leakage."
    )
    content = content.replace(old_text2, new_text2)
    patches_applied += 1
    print("Patch: Graded degradation (len={})".format(len(old_text2)))
else:
    print("Graded degradation markers: start={}, end={}".format(idx_start2, idx_end2))

with open(r"D:\Edge\1\_latex_extracted\main.tex", "w", encoding="utf-8") as f:
    f.write(content)
print("Total patches: {}".format(patches_applied))
