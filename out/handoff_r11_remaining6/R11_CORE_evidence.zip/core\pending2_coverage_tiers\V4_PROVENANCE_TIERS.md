# V4_PROVENANCE_TIERS.md

Provenance tier definitions for v4 (identical to the frozen v3 tiers). Date:
2026-09-03.

- TIER A: every GT edge of the structural unit has independently verifiable
  protocol-native grounding (transferId-linked Send/Relay).
- TIER B: mixed (≥1 protocol-native and ≥1 heuristic edge in the unit).
- TIER C: heuristic-only.
- PRIMARY = ALL Tier-A source-level fan-out units. Tier B/C: descriptive
  prevalence only, never promoted. (v4 construction is protocol-native by
  design; the tiers remain frozen in case of future grounding gaps.)
