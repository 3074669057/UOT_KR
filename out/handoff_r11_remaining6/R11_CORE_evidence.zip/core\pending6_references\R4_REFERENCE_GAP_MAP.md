# R4_REFERENCE_GAP_MAP.md

R4 Phase-3 新增引用缺口图。规则：每条新增文献必须先服务一个缺口、必须回答"为什么必须引用"；无法回答者不加入（本轮检索 12+ 候选，最终采纳 7）。

## 采纳（7 条）

| citation key | 年 | venue | 支撑的正文位置与主张 | 为什么原 41 条不足 | 直接 prior art / 语境 |
|---|---|---|---|---|---|
| wu2026ettracker | 2026 | Expert Systems with Applications 296:128900 | §2.1 段 1：单链单元 → "更近的工作把单元推进到资金流级……但其对应问题仍是单链内的流向识别" | 原 41 条的单链文献（meiklejohn/weber2019/weber2024）单元为地址/账户/交易，没有 2026 年"以资金流为单元的 AML 追踪"最新参照；需要它来精确刻画"单元差一格"的缺口 | 语境（间接） |
| lin2026waveletaml | 2026 | Scientific Reports 16:1548 | §2.1 段 2："2025–2026 年的进展延续该路线"（图变换 AML 检测） | 原 41 条最新 AML 方法停在 2023/2024（TRacer/Elliptic2），需要 2026 已发表条目证明单链 AML 路线仍在活跃、且仍是单链单元 | 语境 |
| song2024subgraphaml | 2024 | ACM ICAIF '24:195–203 | §2.1 段 2："洗钱子图识别"（子图级 ML AML） | 原 41 条无任何"子图/流级结构"检测条目；它是与本文流级单元最接近的图学习工作，缺它则"流级单元"的谱系不完整 | 语境（近似单元） |
| li2026fedgnn | 2026 | IEEE IoT-J 13(2):2848–2863 | §2.1 段 2："非法账户的联邦图监测"（2026 非法账户监测） | 同上——2026 年账户级监测的时效参照 | 语境 |
| sarkhosh2025darkart | 2025 | APWG eCrime 2025（accepted; arXiv:2509.21831） | §2.1 段 3："对 Web3 洗钱方案的近期分类研究……跨链渠道被滥用的模式" | 原 41 条中洗钱规模证据来自行业报告（chainalysis/elliptic）；需要一篇 2025 同行评审的分类研究把"跨链洗钱模式"写进学术脉络 | 语境 |
| snelgar2025gwot | 2025 | BMVC 2025（BMVA） | §2.3 段 2："2025 年的工作继续以最优传输改进稠密对应……谱系仍在活跃演进" | 原 41 条的 OT 对应文献最新为 2021（LoFTR）；需要 2025 同行评审条目证明"OT 用于对应"不是旧谱系 | 语境（方法基础） |
| liu2026silentledger | 2026 | IEEE TIFS 21:7346–7360 | §4.5："区块链审计机制的最新研究同样把可审计性作为链上系统的一等设计目标" | §4.5 的可审计输出论证只有 2020 前 XAI 引用；需要目标期刊（TIFS）2026 条目支撑"可审计性是当下链上一等设计目标" | 语境 |

## 检索后拒绝（每条给出原因）

| 候选 | 拒绝原因 |
|---|---|
| VeriBridge（Tran et al., VCRIS 2025, DOI 10.1109/vcris68011.2025.11250562） | venue 质量不足（第 2 届 VCRIS）；桥攻击检测与本文桥安全语境重复已有 4 条强引用（li2023/zhou2023/qin2022/apostolaki），不构成新缺口 |
| Li et al., Sci Rep 15:22668 (2025, 10.1038/s41598-025-08365-9) | 与已采纳 lin2026waveletaml 同课题（单链比特币 AML 方法）、且作者组重叠，重复覆盖同一缺口 |
| Li et al., Applied Intelligence 56(6):192 (2026, 10.1007/s10489-026-07232-y) | 同上（同组、同课题冗余） |
| "Detecting Illicit Cross-Chain Fund Movement"（IJAM journal） | 期刊质量存疑（低层级 OA 期刊），QUALITY > COUNT |
| "Following Devils' Footprint"（price manipulation detection） | 无法在 Crossref/出版方核验到正式版本（仅语义学者页），按规则不纳入 |
| "A Security Analysis of Web3.0 Cross-Chain Bridges"（CAICE 2025） | venue 质量不足；桥安全语境无缺口 |
| 韩国 KCI 跨链桥洗钱追踪论文 | 非英文、可及性差 |

## 2025–2026 目标核对

- 目标 10–12 篇；经严格 venue 质量与去冗余过滤后**实际采纳 8 篇**（2025：lin2025connector、zheng2025abctracer、sarkhosh2025darkart、snelgar2025gwot；2026：lin2026waveletaml、wu2026ettracker、liu2026silentledger、li2026fedgnn），落在作者允许的 7–9 实际区间上沿（8 = 7 新增 + 1 既有条目正式版升级计入 2025）。
- QUALITY > COUNT：未为凑数加入任何边缘文献（拒绝清单见上）。
