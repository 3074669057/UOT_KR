# Cross AML

```text
Status: Research prototype / paper artifact
Not production-ready
Not legal or compliance advice
Coverage-qualified outputs only
```

**Cross AML** is an open-source **research prototype** for evidence-qualified cross-chain AML triage. It collects on-chain evidence through RPC, constructs AML flows, applies coverage-qualified RC-UOT-Q-style matching, and emits interpretable correspondence reports.

It is **not** a legal-grade attribution system, **not** a full-scope tracing guarantee, and **not** a claim of universal superiority.

> 中文说明：[USAGE_ZH.md](USAGE_ZH.md)

## Overview

Cross AML helps investigators explore whether source-chain and destination-chain transaction hashes may correspond to the same cross-chain fund movement. The pipeline:

**RPC / mock evidence → flows → features → quotient groups → coverage gate → matcher → abstention → report**

Outputs are **investigation leads** subject to human review ([DISCLAIMER.md](DISCLAIMER.md), [CLAIM_BOUNDARY.md](CLAIM_BOUNDARY.md)).

Dry-run validates the local pipeline; real RPC performance depends on bridge event observability, parser coverage, RPC capabilities, and whether destination candidates are provided.

## Installation

From the repository root (or this directory):

```bash
cd tools/cross_aml
pip install -e ".[dev]"
# minimal: pip install -r requirements.txt pyyaml pytest
```

Requirements: **Python ≥ 3.10**, PyYAML. Tests use pytest (`dev` extra).

**CLI:** Prefer the documented entry point:

```bash
python run_cross_aml.py --config config.example.yaml --input examples/input_pair_scoring.example.json --out /tmp/out --dry-run
```

Optional editable install also exposes `python -m cross_aml.cli` via `cross_aml.cli:main` when installed from `pyproject.toml`.

## Dry-run quickstart (no RPC)

```bash
python run_cross_aml.py \
  --config config.example.yaml \
  --input examples/input_pair_scoring.example.json \
  --out ../../out/cross_aml_reports/mock_demo \
  --dry-run
```

Example hashes in `examples/` are **synthetic mocks** for CI and demos only.

## Live RPC usage

1. `cp .env.example .env` — set `ETHEREUM_RPC_URL`, `BSC_RPC_URL` locally (**never commit** `.env`).
2. Replace mock hashes in your input JSON with **authorized** real transaction hashes.
3. Run without `--dry-run`.

See [RPC_SMOKE_TEST.md](RPC_SMOKE_TEST.md) for a full checklist.

## Modes

### Pair scoring (`pair_scoring`)

Provide `source_tx_hashes` and `destination_tx_hashes`. The tool scores whether constructed flows likely correspond under coverage gates.

### Candidate discovery (`candidate_discovery`)

Provide source hashes only. Destination candidates are discovered heuristically.

**Limitation:** Without `destination_tx_hashes` and without an indexer/archive/trace backend (`search` in config), reports set `candidate_discovery_limited_without_indexer: true`. Large-scale discovery is not guaranteed on standard RPC alone.

## Outputs

| File | Description |
|------|-------------|
| `report.json` / `report.md` | Main investigation report + claim boundary |
| `flows.json` | Constructed source/destination flows |
| `evidence_bundle.json` | Parsed event summary |
| `candidate_pairs.csv` | Non-abstained candidates |
| `abstentions.csv` | Abstained pairs |

## Claim boundary

**Allowed:** evidence-qualified investigation leads; coverage-qualified matching; interpretable hypotheses; abstention on unsupported edges.

**Forbidden:** full-scope high P/R; universal superiority; legal proof; guaranteed discovery; high-confidence match without event evidence; stating that ABCTracer or Connector "failed".

Details: [CLAIM_BOUNDARY.md](CLAIM_BOUNDARY.md)

## Security notes

- Do not commit `.env`, RPC URLs with keys, or private keys ([SECURITY.md](SECURITY.md)).
- Do not commit `out/` from live runs.
- RPC hosts are masked in logs by default.
- `match` in a report is **not** a legal conclusion.

## Tests

```bash
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest tests
```

## Documentation index

| Document | Purpose |
|----------|---------|
| [QUICKSTART.md](QUICKSTART.md) | Short commands |
| [USAGE_EN.md](USAGE_EN.md) / [USAGE_ZH.md](USAGE_ZH.md) | User guides |
| [CONFIG_SCHEMA.md](CONFIG_SCHEMA.md) | YAML reference |
| [CONTRIBUTING.md](CONTRIBUTING.md) | How to contribute |
| [OPEN_SOURCE_RELEASE_CHECKLIST.md](OPEN_SOURCE_RELEASE_CHECKLIST.md) | Release verification |
| [DISCLAIMER.md](DISCLAIMER.md) | Legal / usage disclaimer |

## Relation to paper experiments

This package reuses **method ideas** from the RC-UOT-Q research codebase. It does **not** retrain Phase models or alter Phase 25/29.1 gates, holdout results, or paper claims.

## Citation

If you use this artifact, please cite the parent work (placeholder until publication):

```bibtex
@misc{crossaml2026,
  title = {Ariadne's Thread: Risk-Constrained Unbalanced Optimal Transport for Cross-Chain Suspicious Fund Flow Correspondence},
  author = {Anonymous Authors},
  year = {2026},
  note = {Research artifact}
}
```

## License

Apache License 2.0 — see [LICENSE](LICENSE).
