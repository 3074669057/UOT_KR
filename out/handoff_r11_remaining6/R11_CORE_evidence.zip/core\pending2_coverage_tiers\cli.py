"""CLI orchestration for Cross AML standalone tool."""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

from cross_aml.abstention import apply_abstention
from cross_aml.chains import get_chain_config
from cross_aml.config import load_tool_input, load_yaml_config, resolve_rpc_url
from cross_aml.coverage import qualify_coverage
from cross_aml.event_fetcher import EventFetcher
from cross_aml.explanation import build_explanation
from cross_aml.feature_builder import build_pair_features
from cross_aml.flow_builder import build_flows_from_events, combine_flows_same_chain
from cross_aml.mock_data import MOCK_DISCOVERY_DST, MOCK_DST_TX, MOCK_SRC_TX
from cross_aml.quotient_builder import assign_quotient_groups
from cross_aml.rcuotq_matcher import score_pair
from cross_aml.report_writer import write_reports
from cross_aml.rpc_client import RpcClient
from cross_aml.schemas import EventRecord, MatchResult
from cross_aml.discovery_limits import (
    DISCOVERY_LIMIT_MESSAGE_EN,
    DISCOVERY_LIMIT_MESSAGE_ZH,
    candidate_discovery_limited,
)
from cross_aml.utils import new_run_id, setup_logging

LOG = logging.getLogger(__name__)


def run_pipeline(
    config_path: str | Path,
    input_path: str | Path,
    out_dir: str | Path,
    *,
    dry_run: bool = False,
) -> dict[str, Any]:
    config = load_yaml_config(config_path)
    if dry_run:
        config.setdefault("tool", {})["mock_rpc"] = True
    tool_input = load_tool_input(input_path)

    log_level = os.environ.get("LOG_LEVEL", "INFO")
    setup_logging(log_level)

    run_id = new_run_id()
    time_window_sec = int(float(tool_input.time_window_hours) * 3600)

    rpc_clients = _build_rpc_clients(config, dry_run=dry_run)
    fetcher = EventFetcher(rpc_clients, dry_run=dry_run)

    src_hashes = _resolve_hashes(tool_input.source_tx_hashes, dry_run, "source")
    dst_hashes = _resolve_hashes(tool_input.destination_tx_hashes, dry_run, "destination", tool_input.mode)

    src_events = fetcher.fetch_events_for_hashes(
        tool_input.source_chain, src_hashes, bridge_protocol=tool_input.bridge_protocol
    )
    dst_events = fetcher.fetch_events_for_hashes(
        tool_input.destination_chain, dst_hashes, bridge_protocol=tool_input.bridge_protocol
    )

    src_flows = combine_flows_same_chain(
        assign_quotient_groups(
            build_flows_from_events(
                tool_input.source_chain,
                src_events,
                time_window_sec=time_window_sec,
                token_filter=tool_input.token_filter,
            ),
            src_events,
        )
    )
    dst_flows = combine_flows_same_chain(
        assign_quotient_groups(
            build_flows_from_events(
                tool_input.destination_chain,
                dst_events,
                time_window_sec=time_window_sec,
                token_filter=tool_input.token_filter,
            ),
            dst_events,
        )
    )

    if tool_input.mode == "candidate_discovery" and not dst_hashes:
        dst_flows = _discovery_candidates(dst_flows, tool_input, dry_run)

    pairs = _build_candidate_pairs(src_flows, dst_flows, tool_input.mode)
    matches: list[MatchResult] = []
    max_delay = float(config.get("coverage", {}).get("max_time_delay_hours", 48))

    for src, dst in pairs:
        feats = build_pair_features(src, dst, src_events, dst_events, max_delay_hours=max_delay)
        cov = qualify_coverage(
            {"source_flow": src, "destination_flow": dst, "features": feats},
            config,
        )
        result = score_pair(src, dst, feats, cov, config)
        result = apply_abstention(result, cov, feats, config)
        result = build_explanation(result, cov, feats)
        matches.append(result)

    events_raw = [_event_dict(e) for e in src_events + dst_events]
    discovery_limited = candidate_discovery_limited(
        mode=tool_input.mode,
        destination_tx_hashes_provided=bool(tool_input.destination_tx_hashes),
        config=config,
        dry_run=dry_run,
    )
    if discovery_limited:
        LOG.warning(DISCOVERY_LIMIT_MESSAGE_EN)

    paths = write_reports(
        out_dir,
        run_id=run_id,
        mode=tool_input.mode,
        source_chain=tool_input.source_chain,
        destination_chain=tool_input.destination_chain,
        inputs={
            "source_tx_hashes": src_hashes,
            "destination_tx_hashes": dst_hashes,
            "time_window_hours": tool_input.time_window_hours,
            "token_filter": tool_input.token_filter,
        },
        flows=src_flows + dst_flows,
        matches=matches,
        events_raw=events_raw,
        candidate_discovery_limited_without_indexer=discovery_limited,
        discovery_limit_message_en=DISCOVERY_LIMIT_MESSAGE_EN,
        discovery_limit_message_zh=DISCOVERY_LIMIT_MESSAGE_ZH,
    )
    LOG.info("Wrote reports to %s", out_dir)
    return {
        "run_id": run_id,
        "paths": {k: str(v) for k, v in paths.items()},
        "match_count": len(matches),
        "candidate_discovery_limited_without_indexer": discovery_limited,
    }


def _build_rpc_clients(config: dict[str, Any], *, dry_run: bool) -> dict[str, RpcClient]:
    if dry_run:
        return {}
    clients: dict[str, RpcClient] = {}
    mask = bool(config.get("security", {}).get("mask_rpc_urls_in_logs", True))
    for name in (config.get("chains") or {}):
        chain_cfg = get_chain_config(config, name)
        url = resolve_rpc_url(chain_cfg)
        if url:
            clients[name] = RpcClient(url, mask_urls=mask)
    return clients


def _resolve_hashes(hashes: list[str], dry_run: bool, role: str, mode: str = "pair_scoring") -> list[str]:
    if hashes:
        return hashes
    if not dry_run:
        if mode == "candidate_discovery" and role == "destination":
            return []
        raise ValueError(f"No {role} transaction hashes provided")
    if role == "source":
        return [MOCK_SRC_TX]
    if mode == "candidate_discovery":
        return []
    return [MOCK_DST_TX]


def _discovery_candidates(dst_flows: list, tool_input, dry_run: bool) -> list:
    if dry_run and not dst_flows:
        from cross_aml.flow_builder import build_flows_from_events
        from cross_aml.event_fetcher import EventFetcher

        ev = EventFetcher({}, dry_run=True).fetch_events_for_hashes(
            tool_input.destination_chain, [MOCK_DST_TX, MOCK_DISCOVERY_DST]
        )
        return build_flows_from_events(
            tool_input.destination_chain, ev, token_filter=tool_input.token_filter
        )
    LOG.warning(
        "Candidate discovery without destination hashes is limited on standard RPC; "
        "use indexer/archive node for large-scale search."
    )
    return dst_flows


def _build_candidate_pairs(src_flows, dst_flows, mode: str):
    pairs = []
    if not dst_flows:
        return pairs
    for s in src_flows:
        for d in dst_flows:
            if s.chain == d.chain:
                continue
            pairs.append((s, d))
    return pairs


def _event_dict(e: EventRecord) -> dict[str, Any]:
    return {
        "chain": e.chain,
        "tx_hash": e.tx_hash,
        "log_index": e.log_index,
        "event_type": e.event_type,
        "transfer_key": e.transfer_key,
        "amount_raw": e.amount_raw,
    }


def main() -> int:
    """Console entry point (also invoked via run_cross_aml.py)."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Cross AML — evidence-qualified cross-chain AML triage (research prototype)",
    )
    parser.add_argument("--config", required=True, help="Path to config YAML")
    parser.add_argument("--input", required=True, help="Path to input JSON")
    parser.add_argument("--out", required=True, help="Output directory for reports")
    parser.add_argument("--dry-run", action="store_true", help="Use mock RPC data (no API keys)")
    args = parser.parse_args()
    result = run_pipeline(args.config, args.input, args.out, dry_run=args.dry_run)
    print(f"Run complete: {result['run_id']}")
    for name, path in result["paths"].items():
        print(f"  {name}: {path}")
    return 0
