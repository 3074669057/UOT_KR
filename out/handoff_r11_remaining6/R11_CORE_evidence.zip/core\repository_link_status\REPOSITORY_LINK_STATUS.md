# REPOSITORY_LINK_STATUS.md

PENDING-5 — status of an anonymous / public repository link for this submission.

## Result

```
ANONYMOUS_REPOSITORY_LINK = NOT_FOUND
```

No anonymous artifact-host URL (anonymous.4open.science, Zenodo, OSF, figshare,
GitLab, or an anonymized GitHub mirror) exists anywhere in the searched corpus.
This is an author fill-in item. No URL was invented and none was derived.

## Search scope (read-only)

| Scope | What was searched |
|---|---|
| R10 / R11 DOCX (both) | full extracted body text, keyword scan |
| `full_manuscript_final.md` §5.10 | Data and Code Availability |
| Stage-2 submission docs | code availability / reproducibility statement / cover letter / author metadata |
| `tools/cross_aml/README.md` | tool-level readme |
| Whole working tree (excl. archives) | `anonymous`, `anonymous.4open.science`, `zenodo`, `osf.io`, `figshare`, `github.com`, `gitlab`, `repository URL`, `code availability` |

## What the manuscripts actually say (verbatim stance, not a link)

- `full_manuscript_final.md` §5.10: 5.10 Data and Code Availability All frozen artifacts referenced in this paper are part of the accompanying reproducibility package (to be released with the camera-ready version; the release URL and open-source license declaration will be inserted at that time). The package is self-contained: its manifest (`R5C_REPRODUCIBILITY_BUNDLE_MANIFEST.md`) enumerates the Cross AML prototype, the frozen evaluation scripts and hash-locked one-shot runner with the separately maintained verifier, the frozen confirmatory artifacts, the v3 failure record and quarantined blocks, and both post-development data-only corpora with their frozen design packages, hash manifests, data manifests, disjointness and adequacy reports, cluster summaries, and collection logs — each referenced by a package-relative path, so no reader depends on author-local machine paths. The v5 data manifest records `method_predictions = 0` and `method_runs = 0`. Raw chain data are re-fetchable from public Ethereum and BNB Smart Chain nodes using the documented block ranges; provider API keys are not released. The Celer anchor/Validation labels used for benchmark construction derive from published Celer data; their redistribution terms are stated in the package. No off-chain identity or exchange-internal data are included. # 6. Conclusion Cross-chain laundering forces AML analysis beyond single-chain transaction tracing to
- R11 extracted paragraph [147]: 伦理与数据使用。 本文仅使用公开链上数据与协议事件，不涉及链下身份信息。地址聚类与跨链关联可能被用于去匿名化，本文的输出设计要求保留证据引用并允许弃权，以降低过度归因风险。
- R11 extracted paragraph [151]: 冻结的预注册文件、哈希清单、执行器、校验器与逐单元原始输出将随投稿以匿名仓库形式提供给审稿人，并在接收后公开 [47,48]【待补：匿名仓库链接（投稿前由作者提供）】。
- R10 extracted paragraph [181]: 审稿期间，代码、冻结配置、保留集划分、重采样脚本与冻结记录哈希通过匿名仓库提供〔待补：匿名仓库链接〕。原始链上交易与桥事件可从公开节点获取〔待补：数据源与区块范围〕。派生的流级标签与合成注入实例将在接收后存入〔待补：存储库名称〕并赋予持久标识符〔待补：DOI〕，许可为〔待补〕。地址级实体标注出于第 6 节所述原因不公开。

## Non-anonymous URLs that DO appear (context only, not a submission artifact link)

- `tools/cross_aml/README.md` contains a BibTeX `author = {Anonymous Authors}` field — a
  citation placeholder, **not** a repository URL.
- Manuscript bibliographies cite `https://cbridge-docs.celer.network/` and
  `https://github.com/celer-network/cBridge-contracts` (third-party bridge documentation,
  reference [51] in the R10/R11 DOCX).
- `out/ec_uot_q_final_v2|v3/freeze/python_dependencies.txt` contains an unrelated
  `-e git+https://github.com/3074669057/MLAGDet.git@...` VCS pin from an earlier phase.

## Verdict

`PENDING-5` cannot be closed from repository material. The manuscript's own availability
sections were written to defer the URL and license to submission time, so the absence of a
link is consistent with the manuscript text and is not a packaging defect.
