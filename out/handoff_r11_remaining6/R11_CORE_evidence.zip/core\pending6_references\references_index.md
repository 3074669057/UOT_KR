# References Index

Companion to `references.bib`. Each entry records **category**, **used_in**, and **purpose** (one sentence).

**Total entries:** 45  
**Cited in manuscript:** 45 (all keys; verified by `check_citations.py`)  
**Duplicates:** none (distinct `bibtex` keys; `weber2019amlbitcoin` and `weber2024elliptic2` are related but non-duplicate)

---

## A. Blockchain AML / cryptocurrency forensics (12)

| Key | Venue / year | used_in | purpose |
|-----|--------------|---------|---------|
| `androulaki2013evaluating` | FC 2013 | related_work | Bitcoin privacy and address-linkability evaluation. |
| `foley2019illegal` | Rev. Financial Studies 2019 | related_work | Scale of illicit activity in cryptocurrency markets. |

| Key | Venue / year | used_in | purpose |
|-----|--------------|---------|---------|
| `meiklejohn2013fistful` | IMC 2013 | intro, related_work | Foundational blockchain payment clustering and deanonymization. |
| `weber2019amlbitcoin` | KDD Workshop / arXiv 2019 | intro, related_work | Elliptic dataset and GCN-based illicit transaction detection. |
| `reid2011analysis` | Springer 2011 | related_work | Early Bitcoin anonymity and traceability analysis. |
| `phillips2018ransomware` | ICBC 2018 | related_work | End-to-end forensic tracing of illicit Bitcoin flows. |
| `eberle2021aphrodite` | IEEE Access 2021 | related_work | Cryptocurrency fraud taxonomy and prevention landscape. |
| `harvey2020cryptocurrency` | J. Financial Crime 2020 | related_work | Investor protection and crypto-crime regulatory context. |
| `monamo2016unsupervised` | AFRICON 2016 | related_work | Unsupervised Bitcoin transaction profiling. |
| `nadarajah2018characterizing` | FC Workshops 2018 | related_work | Entity characterization in Bitcoin networks. |
| `chainalysis2024laundering` | Chainalysis report 2024 | intro, related_work, discussion | Industry-scale crypto money-laundering typologies. |
| `elliptic2025crosschain` | Elliptic report 2025 | intro, related_work, discussion | Cross-chain crime volumes and bridge exploitation. |
| `weber2024elliptic2` | arXiv 2024 | related_work | Subgraph-level AML representation learning (Elliptic2). |

## B. Cross-chain tracing / bridge security (8)

| Key | Venue / year | used_in | purpose |
|-----|--------------|---------|---------|
| `lin2025connector` | IEEE TIFS 2025 | intro, related_work, experiments | **CONNECTOR**—DeFi bridge tx association (adapted baseline). |
| `zheng2025abctracer` | arXiv 2025 | intro, related_work, experiments | **ABCTracer**—bidirectional DeFi cross-chain tracing (adapted baseline). |
| `qin2022rise` | IEEE S&P 2022 | related_work | DeFi payment/channel security context. |
| `zhou2023sok` | arXiv 2023 | related_work | SoK on DeFi attacks and defenses. |
| `loesch2019towards` | FC Workshops 2020 | related_work | DeFi protocol taxonomy. |
| `li2023demystifying` | IEEE S&P Workshops 2023 | related_work | Cross-chain bridge attack surface. |
| `apostolaki2019hijacking` | IEEE S&P 2017 | related_work | Network-layer threats to cryptocurrency routing. |
| `thibodeau2022celer` | Technical doc 2022 | related_work, experiments | Celer/cBridge benchmark protocol context. |

## C. Graph learning / transaction matching / taint / clustering (7)

| Key | Venue / year | used_in | purpose |
|-----|--------------|---------|---------|
| `khalil2018iotc` | IEEE TrustCom 2018 | related_work §2.3 | Graph learning combined with network analysis for cryptocurrency fraud. |
| `chen2021phishing` | IJCAI 2021 | related_work | Ethereum phishing detection via graph methods. |
| `wang2022tracer` | USENIX Security 2022 | related_work | Account-based blockchain transaction tracing (TRacer). |
| `pareja2020evolvegcn` | AAAI 2020 | related_work | Dynamic graph embeddings for temporal transaction graphs. |
| `hamilton2017inductive` | NeurIPS 2017 | related_work | Inductive GNN representation learning. |
| `kipp2021taint` | ACM CSUR 2021 | related_work | Survey of tracing heuristics and learning approaches. |
| `yousaf2023crosschain` | IEEE Access 2023 | related_work | Rule-based cross-chain tracing (CeFi contrast). |

## D. Optimal transport / unbalanced OT / Sinkhorn (8)

| Key | Venue / year | used_in | purpose |
|-----|--------------|---------|---------|
| `cuturi2013sinkhorn` | NeurIPS 2013 | intro, related_work, method | Entropy-regularized OT via Sinkhorn iterations. |
| `peyre2019computational` | FnT ML 2019 | related_work, method | Computational OT algorithms and numerics. |
| `villani2009optimal` | Springer 2009 | intro, related_work, method | Theoretical foundations of optimal transport. |
| `chizat2018scaling` | Math. Comp. 2018 | related_work, method | Scalable algorithms for unbalanced OT. |
| `chizat2018unbalanced` | J. Funct. Anal. 2018 | intro, related_work, method | Unbalanced OT dynamic/Kantorovich formulations. |
| `frogner2015learning` | NeurIPS 2015 | related_work | Wasserstein loss for learning with OT. |
| `benamou2014iterative` | SIAM J. Sci. Comp. 2015 | related_work | Bregman projections for regularized transport. |
| `sejourne2019sinkhorn` | NeurIPS 2021 | related_work | Generalized/unbalanced transport divergences. |

## E. Explainability / auditability / AML deployment / regulation (6)

| Key | Venue / year | used_in | purpose |
|-----|--------------|---------|---------|
| `fatf2023virtualassets` | FATF 2023 | intro, related_work, discussion | Virtual-asset/VASP standards and cross-chain risk. |
| `fatf2021updatedguidance` | FATF 2021 | related_work, discussion | Risk-based approach to VAs and VASPs. |
| `arrieta2020explainable` | Information Fusion 2020 | related_work, discussion | XAI taxonomy for responsible high-stakes decisions. |
| `rudin2019stop` | Nature MI 2019 | discussion | Prefer interpretable models in regulated settings. |
| `adadi2018peeking` | IEEE Access 2018 | related_work | Survey of explainable AI methods. |
| `liu2022compliance` | IEEE TSMC 2022 | discussion | RegTech and AML compliance technology. |

## F. Tool / artifact / reproducibility (3)

| Key | Venue / year | used_in | purpose |
|-----|--------------|---------|---------|
| `pineau2021improving` | JMLR 2021 | discussion | ML reproducibility standards (artifact alignment). |
| `lamprecht2019research` | Data Science 2019 | discussion | FAIR principles for research software. |
| `chen2019reproducibility` | EuroS&P Workshops 2019 | discussion | Reproducibility challenges in security ML. |

---

## arXiv-only references (and rationale)

| Key | Why arXiv |
|-----|-----------|
| `zheng2025abctracer` | Current DeFi cross-chain baseline; peer-reviewed venue pending—required for ABCTracer comparison. |
| `weber2024elliptic2` | Latest Elliptic subgraph dataset preprint; no journal version located at index time. |
| `zhou2023sok` | DeFi SoK preprint widely cited in security literature. |

All other required items (Meiklejohn, Weber 2019, CONNECTOR/TIFS, Cuturi, Chizat×2, Villani, Peyré–Cuturi, FATF) use proceedings, journal, book, or official report forms where available.

---

## Citations by manuscript section

### Introduction (11 keys)

`chainalysis2024laundering`, `elliptic2025crosschain`, `meiklejohn2013fistful`, `weber2019amlbitcoin`, `lin2025connector`, `zheng2025abctracer`, `fatf2023virtualassets`, `cuturi2013sinkhorn`, `chizat2018unbalanced`, `villani2009optimal`, `reid2011analysis`

### Related Work (40+ keys)

All categories A–E; primary density in §2.1–2.5.

### Method background (`03_tool_and_design.md`)

`cuturi2013sinkhorn`, `chizat2018unbalanced`, `chizat2018scaling`, `peyre2019computational`, `villani2009optimal`

### Discussion (`05_discussion.md`)

`fatf2023virtualassets`, `fatf2021updatedguidance`, `rudin2019stop`, `arrieta2020explainable`, `chainalysis2024laundering`, `elliptic2025crosschain`, `pineau2021improving`, `liu2022compliance`

---

## Citation hygiene (2026-05-25 clean-up)

| Check | Result |
|-------|--------|
| `python check_citations.py` | **PASS** (45/45 cited; 0 missing; 0 false bare-@) |
| `hit@k` / `top-k` false positives | None in current manuscript; checker excludes metric notation |
| `full_manuscript_final.md` | Regenerated from `00`–`06` with bibliography |
