# RUN_MANIFEST — Conditional-Plan Holdout Preregistration (DESIGN ONLY)

Date: 2026-09-02 (Asia/Shanghai). Output root:
`out/multi_bridge_expansion/conditional_plan_holdout_preregistration/`.
THIS ROUND IS DESIGN ONLY. No holdout data was generated; seeds 301-305 were not
generated or read; the manuscript, candidate, cost, marginals, parameters, and D4 were
not modified. The future runner and verifier were written but NOT executed.

## Package contents

- `HOLDOUT_PREREGISTRATION.md` — candidate identity (hash-locked 0f360add…),
  holdout identity (301-305 × Celer/Multi/Poly × 48 templates), the five
  preregistered methods, primary hypothesis, mechanistic co-primary criteria,
  recovery criterion (+ degenerate-denominator rule), secondary comparisons.
- `HOLDOUT_ANALYSIS_PLAN.md` — frozen paired hierarchical bootstrap algorithm
  (bridge × seed × template paired units; B = 4000 replicates; RNG seed 20240101),
  multiple-comparison hierarchy, bridge-consistency rule, exact-recovery reporting.
- `HOLDOUT_DECISION_RULES.md` — success tree (A–E → DECODER_REPAIR_CONFIRMED),
  independent TYPE A/B/C/D classification, HETEROGENEOUS_EFFECT rule.
- `EXPECTED_CLAIM_MAPPING.md` — conditional wording only (no holdout numbers).
- `HASH_MANIFEST.json` — external hash registry (all spec files + future scripts +
  candidate reference + git/timestamp/environment).
- Future scripts (written, NOT executed): `scripts/multi_bridge/holdout/run_locked_holdout.py`
  (hash gate + explicit `--execute-holdout` flag; body implemented only after approval)
  and `scripts/multi_bridge/holdout/verify_locked_holdout.py` (design stub; refuses to run
  before approval).

## Frozen statistical settings (recorded)

- Primary endpoint: macro edge F1 (unweighted mean over the three bridges).
- Primary contrast: Δ_primary = F1(CONDITIONAL_UOT_D4) − F1(RAW_UOT_PLAN_D4), direction > 0.
- Paired bootstrap: per-bridge template-paired resampling, then bridge-macro;
  B = 4000; RNG = numpy.random.RandomState(20240101).
- recovery_fraction = (F1_c − F1_r)/(F1_cost − F1_r); threshold 0.75; degenerate-
  denominator alternative pre-registered.
- Secondary: Δ_cost, Δ_support, Δ_unbalanced (classification only; never promoted).

## Integrity ledger

candidate spec hash verified against the manifest before this round (match) ·
preregistration package hash-locked externally · 301-305 never generated/read ·
42-46 never used for selection · manuscript NOT modified · no parameter/cost/marginal/
decoder/generator change · no holdout results exist.

## Sensitive info

No API keys or credentials appear in any artifact.
