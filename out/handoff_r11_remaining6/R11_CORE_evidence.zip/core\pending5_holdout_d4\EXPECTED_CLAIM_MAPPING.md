# EXPECTED_CLAIM_MAPPING.md

Date: 2026-09-02 (Asia/Shanghai). Written BEFORE holdout execution. Contains ONLY
conditional wording templates. No holdout numbers exist and none may be inserted here.
The manuscript remains frozen this round and in the future holdout-execution round.

## If DECODER_REPAIR_CONFIRMED (regardless of TYPE)

"On the untouched holdout seeds (301-305, three bridges, 48 templates per seed), the
dual-cancelled conditional-plan decoder improved edge F1 over the raw transport-plan
decoder with a paired 95% CI excluding zero, and the improvement was accompanied by a
reduction of the dual-scaling harmful flips — the decoder-repair hypothesis is
supported. All parameters, the cost, the marginals, and the decoder were locked before
the holdout was run."

## If TYPE B confirms (repair confirmed, no positive transport value)

"The conditional decoder restores the plan's correspondence ranking to the kernel/cost
level, but does not exceed cost-only or support-plus-kernel decoding; in this clean
structural benchmark the transport layer contributes support and mass handling but no
additional ranking value beyond the cost. The transport ranking should therefore be
reported as repaired, not as a source of new correspondence signal."

## If TYPE A occurs (repair confirmed AND positive transport value)

"The conditional decoder exceeds both the cost ceiling and the support-plus-kernel
reference on the untouched holdout, indicating positive transport ranking value beyond
kernel decoding. This result would reopen the question of transport-level contributions
and requires a separate discussion with human approval before any claim upgrade."

## If TYPE C occurs (partial repair)

"The conditional decoder improves over the raw plan but recovers less than 75% of the
cost-level gap on holdout; the decoder-repair hypothesis is only partially supported
and the mechanism explanation is incomplete."

## If TYPE D occurs (failed repair) or verification fails

"The conditional-plan decoder did not reproduce the development improvement on the
untouched holdout; the development result must be treated as development-only and no
decoder-repair claim is made. The raw-plan decoder remains the reference."

## If HETEROGENEOUS_EFFECT

"The improvement is heterogeneous across bridges (at least one bridge shows a strong
reversal); the aggregate result must not be reported as uniform, and the bridge-level
breakdown is presented in full."

## Prohibited wordings (any outcome)

- No claim that RC-UOT-Q "proves superior to all baselines".
- No re-labeling of the old edge-inclusion metric as exact recovery.
- No LEVEL upgrade on the basis of this round's holdout alone; any manuscript change
  requires separate human approval.
- No bridge removal, no post-hoc endpoint switching, no retrospective promotion of
  secondary comparisons.
