"""Configuration loader for Cross AML."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import yaml

from cross_aml.utils import is_valid_tx_hash, normalize_tx_hash
from cross_aml.schemas import ToolInput


def load_yaml_config(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    with p.open(encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def load_tool_input(path: str | Path) -> ToolInput:
    p = Path(path)
    with p.open(encoding="utf-8") as f:
        raw = json.load(f)
    src = [normalize_tx_hash(h) for h in raw.get("source_tx_hashes", [])]
    dst = [normalize_tx_hash(h) for h in raw.get("destination_tx_hashes", [])]
    for h in src + dst:
        if not is_valid_tx_hash(h):
            raise ValueError(f"Invalid transaction hash: {h}")
    mode = raw.get("mode", "pair_scoring")
    if mode not in ("pair_scoring", "candidate_discovery"):
        raise ValueError(f"Unsupported mode: {mode}")
    return ToolInput(
        mode=mode,
        source_chain=str(raw.get("source_chain", "ethereum")).lower(),
        destination_chain=str(raw.get("destination_chain", "bsc")).lower(),
        source_tx_hashes=src,
        destination_tx_hashes=dst,
        time_window_hours=float(raw.get("time_window_hours", 24)),
        token_filter=[str(t).upper() for t in raw.get("token_filter", [])],
        bridge_protocol=str(raw.get("bridge_protocol", "generic")),
    )


def resolve_rpc_url(chain_cfg: dict[str, Any]) -> str | None:
    env_key = str(chain_cfg.get("rpc_env", "")).strip()
    if not env_key:
        return None
    return os.environ.get(env_key, "").strip() or None


def merge_config(base: dict[str, Any], overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    out = dict(base)
    if not overrides:
        return out
    for k, v in overrides.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = merge_config(out[k], v)
        else:
            out[k] = v
    return out
