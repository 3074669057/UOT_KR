# MACHINERY_PREFLIGHT_REPORT.md

Date: 2026-09-02 (Asia/Shanghai). Execution-machinery preflight (design only). No holdout
data was generated or read; the holdout execution path was never entered.

## Results

| check | result |
| --- | --- |
| candidate spec SHA256 verified (0f360add…) | PASS |
| preregistration hashes verified before changes | PASS (all 8) |
| HOLDOUT_DECISION_RULES.md clarification amendment | minimal, documented in-file (mechanism gate B macro-level operationalization; convergence-failure residual criteria) |
| runner dev preflight reproduces anchors | PASS (max deviation 2.82e-05 vs 4-decimal anchors; tolerance 5e-4) |
| runner dev preflight decision | DECODER_REPAIR_CONFIRMED + TYPE B (matches development) |
| independent verifier dev preflight | PASS (recomputed from raw cells; macro F1 and Δ_primary match within 1e-9; classification matches) |
| no-flag refusal | PASS (GUARD PATH only; "REFUSING … --execute-holdout") |
| tampered hash | DETECTED before any data access |
| wrong seeds / k=6 / reg=0.1 / reg_m=1.0 / missing method | all DETECTED by identity_check |
| 301-305 artifacts anywhere in the preflight area | NONE |
| bootstrap frozen | B=4000, RNG seed 20240101 (in code and ANALYSIS_PLAN) |
| final freeze | all machinery + docs re-hashed into the external HASH_MANIFEST.json |

## Terminology audit (per instructions)

- RUNNER GUARD PATH INVOKED: YES (no-flag run and verifier design-refusal).
- HOLDOUT EXECUTION PATH ENTERED: NO.
- 301–305 GENERATED: NO.
- 301–305 READ: NO.

## Frozen final machinery (no more code changes before holdout execution)

- `scripts/multi_bridge/holdout/holdout_common.py` (frozen statistics + gates)
- `scripts/multi_bridge/holdout/run_locked_holdout.py` (one-shot runner; hard gates)
- `scripts/multi_bridge/holdout/verify_locked_holdout.py` (independent verifier)
- `scripts/multi_bridge/holdout/run_holdout_preflight_tests.py` (negative tests)
- Hashes: external `HASH_MANIFEST.json` (authoritative).

Final status: **HOLDOUT_EXECUTION_MACHINERY_LOCKED_FOR_FINAL_APPROVAL**
