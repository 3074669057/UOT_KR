# TEMPORAL_EXTERNAL_PROVENANCE_TIERS.md

Component-level provenance tier definitions, frozen by
CLARIFICATION_AMENDMENT_BEFORE_DATA_COLLECTION.md §2A. Date: 2026-09. These
definitions apply at GT-construction time and may not change afterward.

## 1. Edge-level grounding (unchanged from the GT protocol)

- PROTOCOL-NATIVE edge: the anchor edge carries the frozen 11-field provenance
  and its cross-chain linkage is grounded in protocol-native / independently
  verifiable evidence (transferId, Send, Relay, Mint/burn, source and
  destination event/log identities as applicable).
- `heuristic_link` edge: linkage established only by the frozen heuristic
  matching rule (amount, asset, receiver, time window); recorded as a lower
  provenance tier, never silently upgraded.

## 2. Component-level tiers (frozen)

- **TIER A — PROTOCOL-NATIVE COMPONENT:** EVERY GT edge of the structural
  component is protocol-native grounded per §1.
- **TIER B — MIXED COMPONENT:** at least one edge protocol-native grounded AND
  at least one edge `heuristic_link`.
- **TIER C — HEURISTIC-ONLY COMPONENT:** no edge reaches protocol-native
  grounding.

## 3. Population rules (frozen)

- PRIMARY STRUCTURAL POPULATION = ALL eligible TIER-A real 1→N fan-out
  components, INCLUDING degree > 5 (no k-based exclusion).
- TIER B: secondary descriptive only.
- TIER C: NOT admissible as primary structural GT; reported only as prevalence /
  provenance limitation.
- Tier B/C may never be upgraded into the primary population because Tier A is
  scarce. If the Tier-A population fails the frozen adequacy gates, the outcome
  is EXTERNAL_STRUCTURAL_ENDPOINT_NOT_EVALUABLE (an allowed result).

## 4. Status this round

No v3 corpus was constructed (Stage A live checks failed in this environment;
see STAGE_A_LIVE_AVAILABILITY_REPORT.md), so no component has been classified.
The tier machinery is definition-complete and will be applied verbatim in the
execution environment.
