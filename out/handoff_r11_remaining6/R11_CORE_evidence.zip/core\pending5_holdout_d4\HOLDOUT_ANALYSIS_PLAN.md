# HOLDOUT_ANALYSIS_PLAN.md

Date: 2026-09-02 (Asia/Shanghai). Frozen BEFORE holdout execution. This plan may not be
modified after holdout observation.

## 1. Observation unit and pairing

- Every method is evaluated on the SAME bridge × seed × template instances
  (3 bridges × 5 seeds × 48 templates = 720 template observations per method).
- Per-template metrics (as in all previous rounds): edge precision / recall / F1,
  split-edge F1, merge-edge F1, strict exact recovery (overall/split/merge), FP per
  template, FN per template, predicted edges per template, coverage, GT mutual-top5
  retention (cost-level and plan-level), GT row/column ranks.
- Paired contrasts are computed on the SAME template rows (method pairing preserved).

## 2. Aggregation hierarchy (frozen)

1. per-template metric → per-seed mean over 48 templates;
2. per-bridge mean over 5 seeds; per-bridge std over 5 seed-means;
3. macro = unweighted mean over the three bridges (equal bridge weight).
Edge-level pooling across templates is NEVER used for CI (no IID-edge inflation).

## 3. Paired bootstrap (exact algorithm, frozen)

For a paired contrast Δ of method X minus method Y, with template-level paired
observations d(t) = m_X(t) − m_Y(t):

1. Group paired observations by bridge: D_b = {d(t)} for templates of bridge b.
2. For bootstrap replicate r = 1..B:
   a. for each bridge b: resample D_b WITH replacement (size |D_b|, preserves pairing);
   b. compute per-bridge paired mean m_b(r);
   c. replicate statistic = mean over bridges of m_b(r).
3. 95% CI = [2.5th, 97.5th] percentile of the B replicate statistics.
4. Per-bridge paired means and per-bridge 95% CIs are reported identically at the
   bridge level (resampling D_b only).

- B = 4000 (number of replicates, frozen).
- RNG = numpy.random.RandomState(20240101) (bootstrap seed, frozen).
- Reported: per-bridge mean, per-bridge std (of seed-means), macro mean, paired Δ,
  95% paired CI. No alternative bootstrap definition may be used afterwards.

## 4. Multiple comparisons (frozen hierarchy; no post-hoc promotion)

- PRIMARY: Δ_primary = CONDITIONAL_UOT_D4 − RAW_UOT_PLAN_D4 (macro edge F1).
- MECHANISTIC CO-PRIMARY: harmful-flip reductions + GT mutual-top5 retention
  (reported descriptively per bridge with the same paired bootstrap; direction must
  agree with the primary, magnitudes are not held to the development values).
- SECONDARY: Δ_cost (vs AMOUNT_FREE_COST_D4), Δ_support (vs SUPPORT_PLUS_K_D4),
  Δ_unbalanced (vs CONDITIONAL_BOT_D4). Secondary results can never be re-labeled
  primary after observation.

## 5. Bridge consistency

All three bridges are reported separately AND as macro. No bridge may be removed
after observation. If the macro primary succeeds but one bridge reverses strongly
(its paired CI excludes 0 in the negative direction), the result is marked
HETEROGENEOUS_EFFECT and discussed explicitly; it is not hidden and not averaged away.

## 6. Exact recovery

Strict exact structural recovery is reported as a secondary descriptive metric
(per bridge and macro). It is NOT the primary endpoint. The old edge-inclusion
"split/merge recovery" metric must not be presented as exact recovery anywhere in the
holdout report.

## 7. Solver / implementation status

The frozen solves run with the frozen parameters; convergence status and residuals are
recorded per cell and reported. Any non-converged cell triggers the failure rule E in
HOLDOUT_DECISION_RULES.md (no silent acceptance).

## 8. Outputs (fixed list)

raw per-template CSV per (bridge, seed, method) · per-seed table · per-bridge table ·
macro table · paired bootstrap table · mechanism table · solver-status table ·
independent verification report · holdout report. No other aggregation is invented.
