# R7 generator structural validation (Stage 0B)

* generated: 2026-09-17T07:16:19Z
* result: **PASS**
* method F1 computed before this validation: **NO**

## Checks

| check | status | detail |
|---|---|---|
| `family_count_24_per_cell` | **PASS** | `{"cells": 30, "observed": [24]}` |
| `instances_2_per_family` | **PASS** | `[[2]]` |
| `base_anchor_clusters_disjoint` | **PASS** | `{"unique_anchors": [48], "violations": []}` |
| `unmatched_1_per_template` | **PASS** | `[48]` |
| `decoys_2_per_template` | **PASS** | `[96]` |
| `label_consistency` | **PASS** | `[]` |
| `split_merge_topology` | **PASS** | `[]` |
| `split_degree_matches_target` | **PASS** | `{"total_variation": 0.016280699552319953, "observed": [0.5784722222222223, 0.2076388888888889, 0.08402777777777778, 0.043055555555555555, 0.02013888888888889, 0.013888888888888888, 0.05277777777777778], "target": [0.5801` |
| `merge_degree_matches_target` | **PASS** | `{"total_variation": 0.004705831608005523, "observed": [0.9798611111111111, 0.02013888888888889, 0.0, 0.0, 0.0, 0.0, 0.0], "target": [0.9751552795031055, 0.024844720496894408, 0.0, 0.0, 0.0, 0.0, 0.0], "n_draws": 1440}` |
| `degree_within_frozen_range` | **PASS** | `{"range": [2, 8], "cap": 8, "max_observed": 8}` |
| `all_solver_converged` | **PASS** | `30` |
| `no_duplicate_cells` | **PASS** | `30` |

## Per-cell structure

| bridge | seed | templates | families | unique anchors | src | dst | unmatched | decoys | positives | converged |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| Celer | 206 | 48 | 24 | 48 | 289 | 331 | 48 | 96 | 332 | True |
| Celer | 207 | 48 | 24 | 48 | 289 | 346 | 48 | 96 | 347 | True |
| Celer | 208 | 48 | 24 | 48 | 288 | 319 | 48 | 96 | 319 | True |
| Celer | 209 | 48 | 24 | 48 | 290 | 346 | 48 | 96 | 348 | True |
| Celer | 210 | 48 | 24 | 48 | 290 | 332 | 48 | 96 | 334 | True |
| Celer | 211 | 48 | 24 | 48 | 289 | 364 | 48 | 96 | 365 | True |
| Celer | 112 | 48 | 24 | 48 | 291 | 331 | 48 | 96 | 334 | True |
| Celer | 113 | 48 | 24 | 48 | 289 | 319 | 48 | 96 | 320 | True |
| Celer | 114 | 48 | 24 | 48 | 289 | 333 | 48 | 96 | 334 | True |
| Celer | 115 | 48 | 24 | 48 | 288 | 329 | 48 | 96 | 329 | True |
| Multi | 206 | 48 | 24 | 48 | 288 | 327 | 48 | 96 | 327 | True |
| Multi | 207 | 48 | 24 | 48 | 288 | 326 | 48 | 96 | 326 | True |
| Multi | 208 | 48 | 24 | 48 | 288 | 328 | 48 | 96 | 328 | True |
| Multi | 209 | 48 | 24 | 48 | 288 | 343 | 48 | 96 | 343 | True |
| Multi | 210 | 48 | 24 | 48 | 289 | 338 | 48 | 96 | 339 | True |
| Multi | 211 | 48 | 24 | 48 | 288 | 329 | 48 | 96 | 329 | True |
| Multi | 112 | 48 | 24 | 48 | 289 | 372 | 48 | 96 | 373 | True |
| Multi | 113 | 48 | 24 | 48 | 290 | 323 | 48 | 96 | 325 | True |
| Multi | 114 | 48 | 24 | 48 | 289 | 337 | 48 | 96 | 338 | True |
| Multi | 115 | 48 | 24 | 48 | 289 | 328 | 48 | 96 | 329 | True |
| Poly | 206 | 48 | 24 | 48 | 288 | 340 | 48 | 96 | 340 | True |
| Poly | 207 | 48 | 24 | 48 | 289 | 311 | 48 | 96 | 312 | True |
| Poly | 208 | 48 | 24 | 48 | 289 | 323 | 48 | 96 | 324 | True |
| Poly | 209 | 48 | 24 | 48 | 290 | 334 | 48 | 96 | 336 | True |
| Poly | 210 | 48 | 24 | 48 | 290 | 332 | 48 | 96 | 334 | True |
| Poly | 211 | 48 | 24 | 48 | 290 | 354 | 48 | 96 | 356 | True |
| Poly | 112 | 48 | 24 | 48 | 288 | 328 | 48 | 96 | 328 | True |
| Poly | 113 | 48 | 24 | 48 | 289 | 334 | 48 | 96 | 335 | True |
| Poly | 114 | 48 | 24 | 48 | 289 | 346 | 48 | 96 | 347 | True |
| Poly | 115 | 48 | 24 | 48 | 289 | 336 | 48 | 96 | 337 | True |

## Sampled degree distribution vs frozen target

| degree | sampled split p | frozen split p | sampled merge p | frozen merge p |
|---:|---:|---:|---:|---:|
| 2 | 0.5785 | 0.5801 | 0.9799 | 0.9752 |
| 3 | 0.2076 | 0.1942 | 0.0201 | 0.0248 |
| 4 | 0.0840 | 0.0812 | 0.0000 | 0.0000 |
| 5 | 0.0431 | 0.0461 | 0.0000 | 0.0000 |
| 6 | 0.0201 | 0.0242 | 0.0000 | 0.0000 |
| 7 | 0.0139 | 0.0166 | 0.0000 | 0.0000 |
| 8 | 0.0528 | 0.0576 | 0.0000 | 0.0000 |

* split total variation distance: `0.016281`
* merge total variation distance: `0.004706`

## Cluster / duplication audit

* every template inside every (bridge, seed) cell has a DISTINCT base anchor
* therefore no base-anchor cluster is shared by two families, and the base-anchor cluster sensitivity analysis has 48 disjoint clusters per cell
* family manifest rows: 1440 (3 bridges x 10 selection seeds x 24 families x 2 instances)

