# R7 selection report (Stage 0)

* generated: 2026-09-17T07:51:08Z
* experiment: `r7_confirmatory_kernel_ranking_20260917`
* selection block: `[206, 207, 208, 209, 210, 211, 112, 113, 114, 115]` (amended from `[206, 207, 208, 209, 210, 211, 212, 213, 214, 215]`; see BLOCKER_REPORT.md)
* confirmatory holdout `401-410`: **reserved, not generated, not read**
* this stage is **exploratory / selection**; nothing here is confirmatory evidence

## 1. Real degree calibration

Source: frozen v4 / v5 audit windows, recomputed from the canonical edge lists.

| window | canonical edges | fan-out units (>=2) | fan-in units (>=2) | max fan-out | max fan-in |
|---|---:|---:|---:|---:|---:|
| v4 | 25621 | 2451 | 85 | 20 | 3 |
| v5 | 39595 | 5516 | 76 | 164 | 3 |

* v4 fan-out histogram exactly reproduces the frozen v4 final report: `True`
* v5 manifest cross-check: edges match `True`, fan-out units match `True`

### Pooled truncated distribution (the frozen generator input)

| degree | split (fan-out) count | split p | merge (fan-in) count | merge p |
|---:|---:|---:|---:|---:|
| 2 | 4622 | 0.5801 | 157 | 0.9752 |
| 3 | 1547 | 0.1942 | 4 | 0.0248 |
| 4 | 647 | 0.0812 | 0 | 0.0000 |
| 5 | 367 | 0.0461 | 0 | 0.0000 |
| 6 | 193 | 0.0242 | 0 | 0.0000 |
| 7 | 132 | 0.0166 | 0 | 0.0000 |
| 8 | 459 | 0.0576 | 0 | 0.0000 |

### Truncation tail

* rule: `d_used = min(d_observed, 8)` (right winsorisation, not deletion)
* split: n=7967, P(d>8)=0.045940, observed max=164, median=2.0, q75=3.0, q90=5.0, q95=8.0
* merge: n=161, P(d>8)=0.000000, observed max=3
* **HIGH_TRUNCATION_TAIL = False**
* fan-in is empirical, not a mirrored proxy: `mirrored_proxy_not_empirical_fanin = False`
* v4/v5 duplicate anchored units: shared canonical anchors = 0 -> deduplication not required

## 2. Generator: 24 families

* families per bridge/seed: **24**, instances per family: **2**, templates per cell: **48**
* family grid: 4 amount quartiles x 6 delay sextiles
* 12 **original** families = first half of each frozen 4x3 cell (sextiles 0,2,4)
* 12 **new** families = second half of each frozen cell (sextiles 1,3,5)
* every template in every cell has a DISTINCT base anchor, so base-anchor clusters are disjoint by construction
* structural QA: **PASS** (completed before any method F1 was computed: `method_f1_computed = False`)
* family manifest: `r7_confirmatory_kernel_ranking_20260917\selection\generator\family_manifest.csv` (1440 rows, sha256 `a11c7ca53d127579...`)

| check | status |
|---|---|
| `family_count_24_per_cell` | PASS |
| `instances_2_per_family` | PASS |
| `base_anchor_clusters_disjoint` | PASS |
| `unmatched_1_per_template` | PASS |
| `decoys_2_per_template` | PASS |
| `label_consistency` | PASS |
| `split_merge_topology` | PASS |
| `split_degree_matches_target` | PASS |
| `merge_degree_matches_target` | PASS |
| `degree_within_frozen_range` | PASS |
| `all_solver_converged` | PASS |
| `no_duplicate_cells` | PASS |

## 3. Rule candidate space (fixed before any selection F1)

* candidates: **22**
* criterion: highest bridge-balanced overall macro edge F1
* tie-break order: ['R-const', 'R-quantile', 'R-threshold', 'R-adaptive'], then smaller parameter value

## 4. All candidate results (every candidate, not only the winner)

| rule | family | overall macro edge F1 | Celer | Multi | Poly | edges/family |
|---|---|---:|---:|---:|---:|---:|
| `R-const@k3` | R-const | 0.432151 | 0.452564 | 0.384071 | 0.459817 | 17.425 |
| `R-quantile@q0.75` | R-quantile | 0.432151 | 0.452564 | 0.384071 | 0.459817 | 17.425 |
| `R-const@k4` | R-const | 0.350934 | 0.368105 | 0.317616 | 0.367081 | 30.944 |
| `R-const@k2` | R-const | 0.350604 | 0.368298 | 0.312688 | 0.370827 | 7.761 |
| `R-adaptive@a2` | R-adaptive | 0.306308 | 0.317753 | 0.282561 | 0.318611 | 30.186 |
| `R-const@k5` | R-const | 0.305035 | 0.316902 | 0.279824 | 0.318380 | 48.319 |
| `R-quantile@q0.9` | R-quantile | 0.305035 | 0.316902 | 0.279824 | 0.318380 | 48.319 |
| `R-adaptive@a3` | R-adaptive | 0.304648 | 0.315322 | 0.284987 | 0.313636 | 35.279 |
| `R-adaptive@a5` | R-adaptive | 0.302721 | 0.313284 | 0.287497 | 0.307381 | 41.781 |
| `R-adaptive@a4` | R-adaptive | 0.301712 | 0.312108 | 0.286081 | 0.306947 | 38.953 |
| `R-adaptive@a6` | R-adaptive | 0.299873 | 0.311274 | 0.285380 | 0.302964 | 44.049 |
| `R-adaptive@a8` | R-adaptive | 0.298331 | 0.308692 | 0.284437 | 0.301864 | 47.226 |
| `R-threshold@t0.7` | R-threshold | 0.277142 | 0.284987 | 0.261077 | 0.285363 | 82.378 |
| `R-const@k8` | R-const | 0.274856 | 0.278774 | 0.266459 | 0.279335 | 79.388 |
| `R-quantile@q0.95` | R-quantile | 0.274856 | 0.278774 | 0.266459 | 0.279335 | 79.388 |
| `R-threshold@t0.9` | R-threshold | 0.273725 | 0.284392 | 0.251107 | 0.285675 | 80.401 |
| `R-const@k6` | R-const | 0.270925 | 0.280084 | 0.250596 | 0.282096 | 69.550 |
| `R-threshold@t0.5` | R-threshold | 0.270122 | 0.285033 | 0.240527 | 0.284807 | 105.068 |
| `R-threshold@t0.3` | R-threshold | 0.269058 | 0.284010 | 0.238356 | 0.284807 | 108.235 |
| `R-threshold@t0.2` | R-threshold | 0.267634 | 0.281861 | 0.236485 | 0.284555 | 110.907 |
| `R-threshold@t0.1` | R-threshold | 0.266264 | 0.279852 | 0.235371 | 0.283568 | 112.440 |
| `R-threshold@t0.05` | R-threshold | 0.264152 | 0.277483 | 0.232229 | 0.282744 | 116.333 |

Full precision: `selection/rule_search/all_candidates.csv` and `.json`.

## 5. Winner

* **`R-const@k3`** (family `R-const`)
* parameters: `{"family": "R-const", "k": 3}`
* selection score (bridge-balanced overall macro edge F1): **0.432151**
* tied at tolerance 1e-12: 2 -> ['R-const@k3', 'R-quantile@q0.75']
* tie-break applied: **True** (complexity order; R-const before R-quantile)
* mean predicted edges per family: 17.425 (~418 edges per cell)
* `TRUNCATION_BOUNDARY_DEPENDENCE = False` (no reason recorded)

Winner reason: highest bridge-balanced overall macro edge F1 over all 22 pre-registered candidates. `R-quantile@q0.75` derived exactly the same k (ceil(Q_0.75) = 3 from the frozen degree distribution) and therefore scored identically; the pre-registered complexity tie-break selects the simpler `R-const` form. No holdout information was used.

## 6. R-adaptive diagnostics (explanatory only)

* source Spearman(r_i, true fan-out degree), overall: **-0.0004** 95% CI [-0.021786045506230145, 0.020734021512778956], n=8669
* target Spearman(c_j, true fan-in degree), overall: **-0.0000** 95% CI [-0.020250278205943783, 0.020220691167241723], n=10039

| bridge | source rho | target rho |
|---|---:|---:|
| Celer | -0.0024 | 0.0008 |
| Multi | -0.0004 | -0.0002 |
| Poly | 0.0019 | -0.0005 |

These correlations are reported for interpretation only and did not change the selection score.

## 7. Threshold-MM calibration (selection block only)

* criterion: minimise |bridge-balanced mean predicted edge count per family - selected UOT_KR budget|
* uses ground-truth F1: **False**
* UOT_KR target budget (bridge-balanced mean predicted edges per family): **17.4250**
* selected cutoff: **0.230150** (q=0.004), achieved budget 16.1694, |diff| = 1.2556
* grid amendment: the pre-registered coarse quantile grid (q >= 0.02) bound the solution: at q = 0.02 the threshold rule already predicts far more edges per family than the selected UOT_KR rule, so the equal-budget minimum was not attainable inside the grid
  (coarse pre-registered grid best |diff| = 63.1597)
* tie-break: higher threshold

## 8. Dual-Softmax calibration (selection block only)

* acceptance: bidirectional mutual nearest neighbour (never tuned)
* criterion: maximise selection-block bridge-balanced mean family macro edge F1 over the frozen tau grid
* selected tau: **0.0**, score 0.248250
* monotone decreasing in tau: True -> tau = 0 is the global optimum
* historical status: the R5B prior-art module was retired as mis-specified (softmax applied to K instead of log K) and was never executed; R7 provides the complete scheme

| tau | selection score |
|---:|---:|
| 0.0 | 0.248250 |
| 0.005 | 0.238984 |
| 0.01 | 0.237796 |
| 0.015 | 0.225745 |
| 0.02 | 0.208890 |
| 0.024 | 0.142262 |
| 0.03 | 0.000000 |
| 0.05 | 0.000000 |

## 9. Cost hashes and solver diagnostics

| bridge | seed | cost_matrix_sha256 | plan_sha256 | solver converged |
|---|---:|---|---|---|
| Celer | 112 | `716ac9380b558974...` | `9bdf94ad052e5367...` | True |
| Celer | 113 | `663d4cbb99bbbdb6...` | `55b9ca0fa8ce65af...` | True |
| Celer | 114 | `7208b3ff6ef51618...` | `2848e327aa1ff170...` | True |
| Celer | 115 | `196cfb78f4485de0...` | `b15cfa38b59d634f...` | True |
| Celer | 206 | `68a24d338a8701b7...` | `262afe896966ebb9...` | True |
| Celer | 207 | `46e4aed6bda68a7f...` | `e87a39f8e71ecbaa...` | True |
| Celer | 208 | `cf33e845b39e8d4f...` | `e5bee22573f82ff8...` | True |
| Celer | 209 | `a282fe983cdc83c9...` | `638be5504f170a37...` | True |
| Celer | 210 | `ec53df62ffd8a183...` | `77acb064b9a0a118...` | True |
| Celer | 211 | `438078fb2c3ed2a6...` | `9c51395fb220cc04...` | True |
| Multi | 112 | `7f13acda504b4d42...` | `793875f3cea39397...` | True |
| Multi | 113 | `1440e45e218605ec...` | `7779a501f3321d0e...` | True |
| Multi | 114 | `46130dfb793a6968...` | `4f53cd0c00e298ca...` | True |
| Multi | 115 | `59d0e5f60bae4230...` | `ad1206435b406028...` | True |
| Multi | 206 | `51784a82fbcc6e71...` | `d82ef14c719d0c5f...` | True |
| Multi | 207 | `9f34fd083fa6fefa...` | `eedbc5b5e2bd4b07...` | True |
| Multi | 208 | `afc017ba9da25ce1...` | `2055b08f912bd618...` | True |
| Multi | 209 | `b4e4519b1657e257...` | `ae33539c5ddd0a45...` | True |
| Multi | 210 | `80d289a1b0b157b9...` | `a94b1863e2b4e4db...` | True |
| Multi | 211 | `c4170086e5a161b2...` | `4c68e6847f11d9d0...` | True |
| Poly | 112 | `1bf2cc3dc0e164b0...` | `315c64ba81fc2258...` | True |
| Poly | 113 | `f12426e781fe2c32...` | `1f0bc96c7ca3f162...` | True |
| Poly | 114 | `13fc33bac29d8893...` | `0d3e00749aef8f57...` | True |
| Poly | 115 | `657a7225bb6a2f78...` | `dc8b6ef7762aec1d...` | True |
| Poly | 206 | `4ef616cdbaee6b56...` | `da62bfb41d3c6848...` | True |
| Poly | 207 | `b1fae49411071013...` | `0a214ba40a9d396c...` | True |
| Poly | 208 | `69c6460b528a68d1...` | `f345d5993e8645fe...` | True |
| Poly | 209 | `ca1d8e4766ebf034...` | `6974076f2b8bc9e0...` | True |
| Poly | 210 | `fce5a0dd56e16c59...` | `447ac176afee0de9...` | True |
| Poly | 211 | `1ff69a21f5ca8f0a...` | `ddf5ac7360a552a4...` | True |

All methods in a cell consume the SAME `cost_matrix_sha256` and the SAME plan; the plan is solved exactly once per cell and reused by every decoder and every rule candidate.

## 10. Oracle one-to-one ceiling (diagnostic, not a baseline)

| bridge | seed | oracle macro F1 | mean T | mean M |
|---|---:|---:|---:|---:|
| Celer | 112 | 0.7412 | 6.96 | 4.00 |
| Celer | 113 | 0.7600 | 6.67 | 4.00 |
| Celer | 114 | 0.7402 | 6.96 | 4.00 |
| Celer | 115 | 0.7486 | 6.85 | 4.00 |
| Celer | 206 | 0.7439 | 6.92 | 4.00 |
| Celer | 207 | 0.7296 | 7.23 | 4.00 |
| Celer | 208 | 0.7606 | 6.65 | 4.00 |
| Celer | 209 | 0.7269 | 7.25 | 4.00 |
| Celer | 210 | 0.7401 | 6.96 | 4.00 |
| Celer | 211 | 0.7081 | 7.60 | 4.00 |
| Multi | 112 | 0.7007 | 7.77 | 4.00 |
| Multi | 113 | 0.7492 | 6.77 | 4.00 |
| Multi | 114 | 0.7370 | 7.04 | 4.00 |
| Multi | 115 | 0.7461 | 6.85 | 4.00 |
| Multi | 206 | 0.7506 | 6.81 | 4.00 |
| Multi | 207 | 0.7489 | 6.79 | 4.00 |
| Multi | 208 | 0.7470 | 6.83 | 4.00 |
| Multi | 209 | 0.7326 | 7.15 | 4.00 |
| Multi | 210 | 0.7368 | 7.06 | 4.00 |
| Multi | 211 | 0.7452 | 6.85 | 4.00 |
| Poly | 112 | 0.7491 | 6.83 | 4.00 |
| Poly | 113 | 0.7417 | 6.98 | 4.00 |
| Poly | 114 | 0.7282 | 7.23 | 4.00 |
| Poly | 115 | 0.7384 | 7.02 | 4.00 |
| Poly | 206 | 0.7381 | 7.08 | 4.00 |
| Poly | 207 | 0.7666 | 6.50 | 4.00 |
| Poly | 208 | 0.7527 | 6.75 | 4.00 |
| Poly | 209 | 0.7393 | 7.00 | 4.00 |
| Poly | 210 | 0.7435 | 6.96 | 4.00 |
| Poly | 211 | 0.7189 | 7.42 | 4.00 |

The label-informed ceiling answers what the one-to-one output space can reach. It is never a deployable method, never enters H1/H2, and is never used to build a UOT_KR prediction.

## 11. Not done in this stage

* the confirmatory holdout `401-410` was **not** generated, read or evaluated
* no method result from this stage is confirmatory evidence
* no cost weight, epsilon, lambda or normalisation was re-tuned

